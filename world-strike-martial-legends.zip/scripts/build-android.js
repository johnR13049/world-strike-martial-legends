/**
 * Prepares web distribution assets for Android packaging
 */

import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log('🥋 [World Strike] Building web assets for Android...');

// 1. Build Vite web bundle
try {
  execSync('npm run build', { stdio: 'inherit' });
} catch (err) {
  console.error('Failed to build Vite project:', err);
  process.exit(1);
}

// 2. Define source and destination
const distDir = path.resolve(__dirname, '../dist');
const androidAssetsDir = path.resolve(__dirname, '../android/app/src/main/assets/dist');

if (!fs.existsSync(distDir)) {
  console.error('Error: dist directory does not exist after build!');
  process.exit(1);
}

// Ensure target directory exists
if (fs.existsSync(androidAssetsDir)) {
  fs.rmSync(androidAssetsDir, { recursive: true, force: true });
}
fs.mkdirSync(androidAssetsDir, { recursive: true });

// 3. Recursive copy function
function copyRecursive(src, dest) {
  const entries = fs.readdirSync(src, { withFileTypes: true });
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);

    if (entry.isDirectory()) {
      fs.mkdirSync(destPath, { recursive: true });
      copyRecursive(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

copyRecursive(distDir, androidAssetsDir);

console.log(`✅ [World Strike] Successfully copied web bundle to ${androidAssetsDir}`);
console.log('Ready to compile Android APK via ./gradlew assembleDebug');
