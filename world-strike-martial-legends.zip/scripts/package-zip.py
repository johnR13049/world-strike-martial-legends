#!/usr/bin/env python3
import os
import zipfile
import sys

def create_project_zip():
    root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    public_dir = os.path.join(root_dir, 'public')
    os.makedirs(public_dir, exist_ok=True)

    output_zip_public = os.path.join(public_dir, 'world-strike-martial-legends.zip')
    output_zip_root = os.path.join(root_dir, 'world-strike-martial-legends.zip')

    # Exclusions
    exclude_dirs = {
        'node_modules',
        '.git',
        '.aistudio',
        'dev-dist',
        'dist',
        'build',
        '.gradle',
    }

    exclude_extensions = {
        '.zip',
        '.apk',
        '.log',
    }

    print(f"📦 Packaging World Strike: Martial Legends from: {root_dir}")

    for out_path in [output_zip_public, output_zip_root]:
        with zipfile.ZipFile(out_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(root_dir):
                # Filter directories in-place
                dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.vite')]

                for file in files:
                    file_path = os.path.join(root, file)
                    rel_path = os.path.relpath(file_path, root_dir)

                    # Skip self and exclusions
                    ext = os.path.splitext(file)[1].lower()
                    if ext in exclude_extensions:
                        continue
                    if 'world-strike-martial-legends.zip' in file:
                        continue

                    # Add file to zip
                    zipf.write(file_path, rel_path)

        size_kb = os.path.getsize(out_path) / 1024
        print(f"✅ Generated: {out_path} ({size_kb:.1f} KB)")

if __name__ == '__main__':
    create_project_zip()
