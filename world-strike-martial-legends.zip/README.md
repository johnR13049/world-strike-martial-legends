# WORLD STRIKE: MARTIAL LEGENDS 🥋⚡
### 2D Arcade Martial Arts Fighting Game (Web & Android)

**WORLD STRIKE: MARTIAL LEGENDS** is a competitive 2D arcade fighting game featuring 25 original martial artists across 5 authentic disciplines: **Kyokushin Karate**, **Muay Thai**, **Burmese Lethwei**, **Wushu Sanda**, and **Filipino Yaw-Yan**.

---

## 📱 Quick Android APK Build via GitHub Actions

This repository is already configured with an automated CI/CD pipeline (`.github/workflows/build-apk.yml`) to build Android APKs without needing Android Studio installed locally!

### Steps to get your Android APK:

1. **Push this repository to GitHub**:
   ```bash
   git init
   git add .
   git commit -m "Initial commit - World Strike: Martial Legends"
   git branch -M main
   git remote add origin https://github.com/<YOUR_USERNAME>/<YOUR_REPO>.git
   git push -u origin main
   ```

2. **Wait for GitHub Actions to complete**:
   - Go to your repository on GitHub.
   - Click the **Actions** tab.
   - You will see the **Build Android APK** workflow running.
   - Once it turns green (about 2–3 minutes), click on the workflow run.

3. **Download your APK**:
   - Scroll down to the **Artifacts** section at the bottom of the page.
   - Click **WorldStrike-MartialLegends-Debug-APK** to download the ready-to-install `.apk` file directly to your phone or PC!

---

## 💻 Local Development & Testing

### Web Development Server
```bash
# Install dependencies
npm install

# Start Vite development server on port 3000
npm run dev
```

### Build Web Distribution & Prepare Android Assets
```bash
# Builds Vite bundle and copies files to android/app/src/main/assets/dist/
node scripts/build-android.js
```

### Local Android APK Build (via Terminal / Android Studio)
```bash
# Navigate to android folder and build debug APK
cd android
./gradlew assembleDebug

# Output APK will be at:
# android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 🎮 Game Controls

### Keyboard (Player 1):
| Action | Key |
| :--- | :--- |
| Move / Jump / Crouch | `W` `A` `S` `D` |
| Guard / Block | `Space` or `Hold Back` |
| Light Punch (LP) | `J` |
| Heavy Punch (HP) | `U` |
| Light Kick (LK) | `K` |
| Heavy Kick (HK) | `L` |
| Special Technique 1 | `I` |
| Special Technique 2 | `O` |
| Ultimate Finisher (100% Meter) | `P` |
| Pause / Menu | `Esc` |

### Touch / Mobile:
An on-screen virtual arcade D-Pad and 6 responsive combat buttons (`LP`, `HP`, `LK`, `HK`, `SP1`, `SP2`, `ULT`) are built directly into the interface with zero input lag.

---

## 📁 Repository Structure

```
├── .github/
│   └── workflows/
│       └── build-apk.yml       # Automated GitHub Actions workflow to compile Android APK
├── android/
│   ├── app/
│   │   ├── src/main/
│   │   │   ├── AndroidManifest.xml   # Landscape immersive mode & permissions
│   │   │   ├── java/.../MainActivity.kt # Hardware-accelerated offline WebView
│   │   │   └── res/...               # App icons, strings, fullscreen styles
│   │   └── build.gradle              # Android application configuration
│   ├── build.gradle                  # Root gradle configuration
│   ├── settings.gradle               # Project modules
│   └── gradlew / gradlew.bat         # Gradle wrapper executables
├── scripts/
│   ├── build-android.js              # Bundle web app to android assets
│   └── package-zip.py                # Standalone ZIP packager
├── public/
│   └── manifest.json                 # Web App Manifest
├── src/
│   ├── audio/
│   │   └── soundEngine.ts            # Web Audio FM-style SFX & dynamic BGM
│   ├── data/
│   │   ├── roster.ts                 # 25 original fighters & move data
│   │   └── stages.ts                 # 7 international arenas
│   ├── game/
│   │   ├── engine.ts                 # 60 FPS physics, collisions, CPU AI
│   │   └── renderer.ts               # Canvas martial-arts animation & FX
│   ├── components/                   # Arcade UI, Character Select, Move List
│   └── types/fighter.ts              # TypeScript interfaces
├── index.html
├── package.json
└── vite.config.ts
```

---

## 🥋 Roster of 25 Legends

- **Kyokushin Karate**: Kaito Jin, Daiki Sato, Kenjiro Mori, Ren Takahashi, Goro Ishida
- **Muay Thai**: Prasert Singha, Chaiwat Rung, Somchai Decha, Tawin Sakda, Boonchuay Khem
- **Burmese Lethwei**: Zaw Min Oo, Thura Kyaw, Aung Naing, Myo Thet, Ko Htet
- **Wushu Sanda**: Liang Wei, Chen Bao, Zhao Feng, Lin Jun, Wu Tian
- **Filipino Yaw-Yan**: Dante Ramos, Rafael Cruz, Mateo Santos, Isko Dimaculangan, Joaquin Valdez
