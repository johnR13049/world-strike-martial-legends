import { StageData } from '../types/fighter';

export const STAGES_DATA: StageData[] = [
  {
    id: 'japan_dojo',
    name: 'Tokyo Shin Honbu Dojo',
    location: 'Tokyo',
    country: 'Japan 🇯🇵',
    bgSkyGradient: ['#0f172a', '#1e293b'],
    bgArchitectureType: 'japan_dojo',
    floorColor: '#b45309', // polished wood / tatami rim
    lineColor: '#78350f',
    atmosphereParticles: 'leaves',
  },
  {
    id: 'thai_stadium',
    name: 'Rajadamnern Stadium',
    location: 'Bangkok',
    country: 'Thailand 🇹🇭',
    bgSkyGradient: ['#09090b', '#1c1917'],
    bgArchitectureType: 'thai_stadium',
    floorColor: '#1e3a8a', // blue canvas ring
    lineColor: '#dc2626',
    atmosphereParticles: 'sweat_dust',
  },
  {
    id: 'yangon_pit',
    name: 'Bagan Sacred Sand Pit',
    location: 'Yangon',
    country: 'Myanmar 🇲🇲',
    bgSkyGradient: ['#1c1917', '#451a03'],
    bgArchitectureType: 'yangon_pit',
    floorColor: '#a16207', // packed red dirt / sand
    lineColor: '#713f12',
    atmosphereParticles: 'sand_embers',
  },
  {
    id: 'china_mountain',
    name: 'Mount Hua Dragon Terrace',
    location: 'Shaanxi',
    country: 'China 🇨🇳',
    bgSkyGradient: ['#0f172a', '#1e1b4b'],
    bgArchitectureType: 'china_mountain',
    floorColor: '#334155', // ancient granite stone
    lineColor: '#0f172a',
    atmosphereParticles: 'mountain_mist',
  },
  {
    id: 'philippines_gym',
    name: 'Quiapo Rooftop Yaw-Yan Den',
    location: 'Manila',
    country: 'Philippines 🇵🇭',
    bgSkyGradient: ['#18181b', '#27272a'],
    bgArchitectureType: 'philippines_gym',
    floorColor: '#52525b', // worn concrete
    lineColor: '#dc2626',
    atmosphereParticles: 'gym_dust',
  },
  {
    id: 'underground_cage',
    name: 'Kowloon Underground Cage',
    location: 'Hong Kong',
    country: 'International 🌐',
    bgSkyGradient: ['#030712', '#111827'],
    bgArchitectureType: 'underground_cage',
    floorColor: '#262626', // steel plate & rubber
    lineColor: '#eab308',
    atmosphereParticles: 'neon_sparks',
  },
  {
    id: 'grand_arena',
    name: 'World Strike Grand Arena',
    location: 'Tokyo Dome',
    country: 'World Championship 🏆',
    bgSkyGradient: ['#050816', '#1e1b4b'],
    bgArchitectureType: 'grand_arena',
    floorColor: '#09090b', // octagonal tournament canvas
    lineColor: '#6366f1',
    atmosphereParticles: 'confetti',
  },
];
