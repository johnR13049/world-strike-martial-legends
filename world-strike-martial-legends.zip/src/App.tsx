/**
 * World Strike: Martial Legends - Main Application
 */

import React, { useState } from 'react';
import { TitleScreen } from './components/TitleScreen';
import { CharacterSelect } from './components/CharacterSelect';
import { FightScreen } from './components/FightScreen';
import { DossierView } from './components/DossierView';
import { ROSTER_DATA } from './data/roster';
import { STAGES_DATA } from './data/stages';
import { FighterData, StageData } from './types/fighter';
import { sound } from './audio/soundEngine';

type AppScreen = 'TITLE' | 'CHARACTER_SELECT' | 'FIGHT' | 'DOSSIER';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('TITLE');
  const [gameMode, setGameMode] = useState<'ARCADE' | 'VERSUS' | 'TRAINING'>('ARCADE');
  const [isP2Human, setIsP2Human] = useState<boolean>(false);
  const [difficulty, setDifficulty] = useState<'EASY' | 'MEDIUM' | 'HARD' | 'MASTER'>('MEDIUM');
  const [isMuted, setIsMuted] = useState<boolean>(false);

  const [p1Fighter, setP1Fighter] = useState<FighterData>(ROSTER_DATA[0]);
  const [p2Fighter, setP2Fighter] = useState<FighterData>(ROSTER_DATA[5]);
  const [currentStage, setCurrentStage] = useState<StageData>(STAGES_DATA[0]);

  // Arcade ladder progression
  const [arcadeStage, setArcadeStage] = useState<number>(1);
  const TOTAL_ARCADE_STAGES = 5;

  const handleToggleSound = () => {
    const muted = sound.toggleMute();
    setIsMuted(muted);
  };

  const handleSelectMode = (mode: 'ARCADE' | 'VERSUS' | 'TRAINING') => {
    setGameMode(mode);
    setArcadeStage(1);
    setCurrentScreen('CHARACTER_SELECT');
  };

  const handleStartFight = (p1: FighterData, p2: FighterData, stage: StageData) => {
    setP1Fighter(p1);

    if (gameMode === 'ARCADE') {
      // In Arcade mode, select initial opponent from another discipline
      setArcadeStage(1);
      const ladderOpponents = getArcadeOpponents(p1);
      setP2Fighter(ladderOpponents[0]);
      setCurrentStage(STAGES_DATA[ladderOpponents[0].discipline === 'MUAY_THAI' ? 1 : 2]);
    } else {
      setP2Fighter(p2);
      setCurrentStage(stage);
    }

    setCurrentScreen('FIGHT');
  };

  // Get 5 unique ladder rivals across different disciplines for Arcade mode
  const getArcadeOpponents = (player: FighterData): FighterData[] => {
    const pool = ROSTER_DATA.filter((f) => f.id !== player.id);
    const rivals: FighterData[] = [];
    const disciplines: Array<FighterData['discipline']> = [
      'MUAY_THAI',
      'LETHWEI',
      'WUSHU_SANDA',
      'YAW_YAN',
      'KYOKUSHIN',
    ];

    disciplines.forEach((disc) => {
      const match = pool.find((f) => f.discipline === disc && !rivals.includes(f));
      if (match && rivals.length < 5) rivals.push(match);
    });

    while (rivals.length < 5) {
      const fallback = pool[Math.floor(Math.random() * pool.length)];
      if (!rivals.includes(fallback)) rivals.push(fallback);
    }

    return rivals;
  };

  const handleNextArcadeOpponent = () => {
    const nextStageNum = arcadeStage + 1;
    if (nextStageNum <= TOTAL_ARCADE_STAGES) {
      setArcadeStage(nextStageNum);
      const rivals = getArcadeOpponents(p1Fighter);
      const nextOpponent = rivals[nextStageNum - 1] || rivals[0];
      setP2Fighter(nextOpponent);

      // Match stage to opponent's discipline
      let stageIdx = 0;
      if (nextOpponent.discipline === 'MUAY_THAI') stageIdx = 1;
      else if (nextOpponent.discipline === 'LETHWEI') stageIdx = 2;
      else if (nextOpponent.discipline === 'WUSHU_SANDA') stageIdx = 3;
      else if (nextOpponent.discipline === 'YAW_YAN') stageIdx = 4;
      else stageIdx = 6; // Grand Arena for final boss!

      setCurrentStage(STAGES_DATA[stageIdx]);
      sound.announce(`Stage ${nextStageNum}`);
      setCurrentScreen('FIGHT');
    } else {
      // Completed Arcade!
      setCurrentScreen('TITLE');
    }
  };

  return (
    <main className="w-screen h-screen bg-zinc-950 text-white overflow-hidden select-none">
      {currentScreen === 'TITLE' && (
        <TitleScreen
          onSelectMode={handleSelectMode}
          onOpenDossier={() => setCurrentScreen('DOSSIER')}
          onToggleSound={handleToggleSound}
          isMuted={isMuted}
        />
      )}

      {currentScreen === 'CHARACTER_SELECT' && (
        <CharacterSelect
          mode={gameMode}
          isP2Human={isP2Human}
          difficulty={difficulty}
          onStartFight={handleStartFight}
          onBack={() => setCurrentScreen('TITLE')}
          onToggleSound={handleToggleSound}
          isMuted={isMuted}
        />
      )}

      {currentScreen === 'FIGHT' && (
        <FightScreen
          p1Data={p1Fighter}
          p2Data={p2Fighter}
          stage={currentStage}
          mode={gameMode}
          isP2Human={isP2Human}
          difficulty={difficulty}
          arcadeStage={arcadeStage}
          totalArcadeStages={TOTAL_ARCADE_STAGES}
          onMatchComplete={(p1Won) => {
            // Managed inside VictoryModal
          }}
          onNextOpponent={handleNextArcadeOpponent}
          onSelectFighter={() => setCurrentScreen('CHARACTER_SELECT')}
          onMainMenu={() => {
            sound.stopBgm();
            setCurrentScreen('TITLE');
          }}
          onToggleSound={handleToggleSound}
          isMuted={isMuted}
        />
      )}

      {currentScreen === 'DOSSIER' && (
        <DossierView onBack={() => setCurrentScreen('TITLE')} />
      )}
    </main>
  );
}
