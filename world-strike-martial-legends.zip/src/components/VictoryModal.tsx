import React from 'react';
import { FighterEntity } from '../game/engine';
import { Trophy, RotateCcw, Users, Home, Award } from 'lucide-react';
import { sound } from '../audio/soundEngine';

interface VictoryModalProps {
  winner: FighterEntity;
  loser: FighterEntity;
  isPerfect: boolean;
  mode: 'ARCADE' | 'VERSUS' | 'TRAINING';
  arcadeStage: number;
  totalArcadeStages: number;
  onRematch: () => void;
  onNextOpponent: () => void;
  onSelectFighter: () => void;
  onMainMenu: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  winner,
  loser,
  isPerfect,
  mode,
  arcadeStage,
  totalArcadeStages,
  onRematch,
  onNextOpponent,
  onSelectFighter,
  onMainMenu,
}) => {
  const isArcadeVictory = mode === 'ARCADE' && winner.isPlayer;
  const isArcadeDefeat = mode === 'ARCADE' && !winner.isPlayer;
  const isChampion = isArcadeVictory && arcadeStage >= totalArcadeStages;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="bg-zinc-900 border border-zinc-700 w-full max-w-lg rounded-2xl overflow-hidden shadow-2xl flex flex-col scanlines">
        {/* Header Banner */}
        <div className="p-6 bg-gradient-to-r from-amber-600 via-red-600 to-amber-700 text-center relative overflow-hidden">
          <div className="text-zinc-950 font-arcade text-5xl tracking-widest uppercase font-bold drop-shadow-md">
            {isChampion ? 'WORLD STRIKE CHAMPION!' : `${winner.data.name.toUpperCase()} WINS!`}
          </div>
          {isPerfect && (
            <div className="inline-block mt-1 px-3 py-0.5 rounded-full bg-amber-300 text-zinc-950 text-xs font-bold font-tech tracking-wider uppercase shadow">
              ★ PERFECT VICTORY ★
            </div>
          )}
        </div>

        {/* Body Content */}
        <div className="p-6 space-y-5">
          {/* Winner Profile Banner */}
          <div className="flex items-center gap-4 bg-zinc-950/70 p-4 rounded-xl border border-zinc-800">
            <span className="text-4xl">{winner.data.flag}</span>
            <div className="flex-1">
              <div className="text-xs text-amber-400 font-tech uppercase font-bold tracking-wider">
                {winner.data.discipline.replace('_', ' ')} · {winner.data.archetype}
              </div>
              <h3 className="text-2xl font-bold font-arcade tracking-wide text-white">
                {winner.data.name}
              </h3>
              <div className="text-xs text-zinc-300 italic mt-1 font-tech">
                "{winner.data.winQuote}"
              </div>
            </div>
          </div>

          {/* Arcade Progress Indicator */}
          {mode === 'ARCADE' && (
            <div className="p-3 bg-zinc-950/50 rounded-lg border border-zinc-850 flex items-center justify-between font-tech text-xs">
              <span className="text-zinc-400">TOURNAMENT PROGRESS:</span>
              <span className="text-amber-400 font-bold">
                STAGE {arcadeStage} / {totalArcadeStages} {isArcadeVictory ? 'CLEARED' : 'FAILED'}
              </span>
            </div>
          )}

          {/* Match Statistics */}
          <div className="grid grid-cols-3 gap-3 font-tech text-center">
            <div className="p-2.5 bg-zinc-950/60 rounded-lg border border-zinc-850">
              <div className="text-[10px] text-zinc-400 uppercase">Rounds Score</div>
              <div className="text-lg font-bold text-amber-400">
                {winner.roundsWon} - {loser.roundsWon}
              </div>
            </div>
            <div className="p-2.5 bg-zinc-950/60 rounded-lg border border-zinc-850">
              <div className="text-[10px] text-zinc-400 uppercase">Max Combo</div>
              <div className="text-lg font-bold text-red-400">
                {Math.max(winner.comboHits, loser.comboHits)} HITS
              </div>
            </div>
            <div className="p-2.5 bg-zinc-950/60 rounded-lg border border-zinc-850">
              <div className="text-[10px] text-zinc-400 uppercase">Damage Dealt</div>
              <div className="text-lg font-bold text-cyan-400">
                {winner.comboDamage} PTS
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2 pt-2">
            {isArcadeVictory && !isChampion && (
              <button
                onClick={() => {
                  sound.playMenuConfirm();
                  onNextOpponent();
                }}
                className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 font-arcade text-lg font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
              >
                <Trophy className="w-5 h-5 text-zinc-950" />
                <span>ADVANCE TO NEXT OPPONENT</span>
              </button>
            )}

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  sound.playMenuConfirm();
                  onRematch();
                }}
                className="py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white font-tech text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5"
              >
                <RotateCcw className="w-4 h-4 text-amber-400" />
                <span>Rematch</span>
              </button>

              <button
                onClick={() => {
                  sound.playMenuBeep();
                  onSelectFighter();
                }}
                className="py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white font-tech text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5"
              >
                <Users className="w-4 h-4 text-blue-400" />
                <span>Change Fighter</span>
              </button>
            </div>

            <button
              onClick={() => {
                sound.playMenuBeep();
                onMainMenu();
              }}
              className="w-full py-2 bg-zinc-950 hover:bg-zinc-800 text-zinc-400 hover:text-white font-tech text-xs font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5"
            >
              <Home className="w-4 h-4" />
              <span>Main Menu</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
