import React from 'react';
import { FighterData } from '../types/fighter';
import { X, Zap, Shield, Target } from 'lucide-react';

interface MoveListModalProps {
  fighter: FighterData;
  onClose: () => void;
}

export const MoveListModal: React.FC<MoveListModalProps> = ({ fighter, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-zinc-900 border border-zinc-700 w-full max-w-xl rounded-xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-zinc-950 via-zinc-900 to-zinc-950 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-2xl">{fighter.flag}</span>
            <div>
              <div className="text-xs text-amber-400 font-semibold tracking-wider uppercase font-tech">
                {fighter.discipline.replace('_', ' ')} · {fighter.archetype}
              </div>
              <h3 className="text-xl font-bold font-arcade tracking-wider text-white">
                {fighter.name}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4 overflow-y-auto">
          {/* Epithet & Bio */}
          <div className="bg-zinc-950/60 p-3 rounded-lg border border-zinc-800/80">
            <div className="text-xs italic text-amber-300 font-tech">"{fighter.quote}"</div>
            <p className="text-xs text-zinc-300 mt-1 leading-relaxed">{fighter.bio}</p>
          </div>

          {/* Core Controls */}
          <div>
            <h4 className="text-xs font-semibold text-zinc-400 uppercase tracking-wider font-tech mb-2">
              Basic Commands
            </h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="flex items-center justify-between p-2 bg-zinc-800/50 rounded border border-zinc-700/50">
                <span className="text-zinc-300">Light Punch (LP)</span>
                <kbd className="px-2 py-0.5 bg-zinc-900 text-amber-400 rounded font-mono font-bold">J</kbd>
              </div>
              <div className="flex items-center justify-between p-2 bg-zinc-800/50 rounded border border-zinc-700/50">
                <span className="text-zinc-300">Heavy Punch (HP)</span>
                <kbd className="px-2 py-0.5 bg-zinc-900 text-amber-400 rounded font-mono font-bold">U</kbd>
              </div>
              <div className="flex items-center justify-between p-2 bg-zinc-800/50 rounded border border-zinc-700/50">
                <span className="text-zinc-300">Light Kick (LK)</span>
                <kbd className="px-2 py-0.5 bg-zinc-900 text-amber-400 rounded font-mono font-bold">K</kbd>
              </div>
              <div className="flex items-center justify-between p-2 bg-zinc-800/50 rounded border border-zinc-700/50">
                <span className="text-zinc-300">Heavy Kick (HK)</span>
                <kbd className="px-2 py-0.5 bg-zinc-900 text-amber-400 rounded font-mono font-bold">L</kbd>
              </div>
              <div className="flex items-center justify-between p-2 bg-zinc-800/50 rounded border border-zinc-700/50">
                <span className="text-zinc-300">Guard / Block</span>
                <span className="text-amber-400 font-mono text-[11px]">Hold Back / Space</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-zinc-800/50 rounded border border-zinc-700/50">
                <span className="text-zinc-300">Crouch / Low Guard</span>
                <span className="text-amber-400 font-mono text-[11px]">Down + Back / S</span>
              </div>
            </div>
          </div>

          {/* Special Moves */}
          <div>
            <h4 className="text-xs font-semibold text-zinc-400 uppercase tracking-wider font-tech mb-2">
              Signature Special Techniques
            </h4>
            <div className="space-y-2">
              {/* Special 1 */}
              <div className="p-3 bg-zinc-800/60 rounded-lg border border-zinc-700/60 flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <div className="font-bold text-amber-300 text-sm flex items-center gap-1.5 font-tech">
                    <Zap className="w-4 h-4 text-amber-400" />
                    {fighter.moves.special1.name}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] text-zinc-400 font-mono">{fighter.moves.special1.command}</span>
                    <kbd className="px-1.5 py-0.5 bg-purple-900 text-purple-200 rounded text-xs font-bold font-mono">I</kbd>
                  </div>
                </div>
                <p className="text-xs text-zinc-300 leading-snug">{fighter.moves.special1.description}</p>
                <div className="text-[10px] text-zinc-400 font-mono">
                  Damage: <span className="text-amber-300">{fighter.moves.special1.damage}</span> · Hit: <span className="text-cyan-400">{fighter.moves.special1.hitType}</span>
                </div>
              </div>

              {/* Special 2 */}
              <div className="p-3 bg-zinc-800/60 rounded-lg border border-zinc-700/60 flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <div className="font-bold text-amber-300 text-sm flex items-center gap-1.5 font-tech">
                    <Target className="w-4 h-4 text-amber-400" />
                    {fighter.moves.special2.name}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] text-zinc-400 font-mono">{fighter.moves.special2.command}</span>
                    <kbd className="px-1.5 py-0.5 bg-purple-900 text-purple-200 rounded text-xs font-bold font-mono">O</kbd>
                  </div>
                </div>
                <p className="text-xs text-zinc-300 leading-snug">{fighter.moves.special2.description}</p>
                <div className="text-[10px] text-zinc-400 font-mono">
                  Damage: <span className="text-amber-300">{fighter.moves.special2.damage}</span> · Hit: <span className="text-cyan-400">{fighter.moves.special2.hitType}</span>
                </div>
              </div>

              {/* Ultimate */}
              <div className="p-3 bg-red-950/40 rounded-lg border border-red-800/60 flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <div className="font-bold text-red-300 text-sm flex items-center gap-1.5 font-tech">
                    <Shield className="w-4 h-4 text-red-400" />
                    ULTIMATE: {fighter.moves.ultimate.name}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] text-red-300/80 font-mono">Requires 100% Meter</span>
                    <kbd className="px-1.5 py-0.5 bg-red-700 text-white rounded text-xs font-bold font-mono">P</kbd>
                  </div>
                </div>
                <p className="text-xs text-zinc-300 leading-snug">{fighter.moves.ultimate.description}</p>
                <div className="text-[10px] text-zinc-400 font-mono">
                  Damage: <span className="text-red-400 font-bold">{fighter.moves.ultimate.damage}</span> · Hit: <span className="text-cyan-400">{fighter.moves.ultimate.hitType}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-zinc-950 border-t border-zinc-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-white rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
