import React from 'react';
import { FightEngine } from '../game/engine';

interface ArcadeControlsProps {
  engine: FightEngine;
}

export const ArcadeControls: React.FC<ArcadeControlsProps> = ({ engine }) => {
  const handleDirStart = (dir: 'left' | 'right' | 'up' | 'down') => {
    engine.p1Inputs[dir] = true;
  };

  const handleDirEnd = (dir: 'left' | 'right' | 'up' | 'down') => {
    engine.p1Inputs[dir] = false;
  };

  const handleActionStart = (action: keyof typeof engine.p1Inputs) => {
    engine.p1Inputs[action] = true;
  };

  const handleActionEnd = (action: keyof typeof engine.p1Inputs) => {
    engine.p1Inputs[action] = false;
  };

  return (
    <div className="w-full flex items-center justify-between px-3 py-2 select-none touch-none bg-zinc-950/90 border-t border-zinc-800">
      {/* Directional Pad */}
      <div className="grid grid-cols-3 gap-1.5 w-36 h-36">
        <div />
        <button
          type="button"
          onPointerDown={() => handleDirStart('up')}
          onPointerUp={() => handleDirEnd('up')}
          onPointerLeave={() => handleDirEnd('up')}
          className="bg-zinc-800 active:bg-amber-500 rounded text-sm font-bold text-zinc-200 active:text-zinc-950 flex items-center justify-center shadow"
        >
          ▲
        </button>
        <div />

        <button
          type="button"
          onPointerDown={() => handleDirStart('left')}
          onPointerUp={() => handleDirEnd('left')}
          onPointerLeave={() => handleDirEnd('left')}
          className="bg-zinc-800 active:bg-amber-500 rounded text-sm font-bold text-zinc-200 active:text-zinc-950 flex items-center justify-center shadow"
        >
          ◀
        </button>
        <button
          type="button"
          onPointerDown={() => handleActionStart('guard')}
          onPointerUp={() => handleActionEnd('guard')}
          onPointerLeave={() => handleActionEnd('guard')}
          className="bg-zinc-700 active:bg-blue-500 rounded text-xs font-bold text-zinc-300 active:text-white flex items-center justify-center"
        >
          GUARD
        </button>
        <button
          type="button"
          onPointerDown={() => handleDirStart('right')}
          onPointerUp={() => handleDirEnd('right')}
          onPointerLeave={() => handleDirEnd('right')}
          className="bg-zinc-800 active:bg-amber-500 rounded text-sm font-bold text-zinc-200 active:text-zinc-950 flex items-center justify-center shadow"
        >
          ▶
        </button>

        <div />
        <button
          type="button"
          onPointerDown={() => handleDirStart('down')}
          onPointerUp={() => handleDirEnd('down')}
          onPointerLeave={() => handleDirEnd('down')}
          className="bg-zinc-800 active:bg-amber-500 rounded text-sm font-bold text-zinc-200 active:text-zinc-950 flex items-center justify-center shadow"
        >
          ▼
        </button>
        <div />
      </div>

      {/* Arcade Action Buttons Layout */}
      <div className="flex flex-col gap-2">
        {/* Top Row: Punches & Special 1 */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onPointerDown={() => handleActionStart('lightPunch')}
            onPointerUp={() => handleActionEnd('lightPunch')}
            onPointerLeave={() => handleActionEnd('lightPunch')}
            className="w-12 h-12 rounded-full bg-blue-600 active:bg-blue-400 font-bold text-xs text-white shadow-lg active:scale-95 transition-transform flex flex-col items-center justify-center"
          >
            <span>LP</span>
            <span className="text-[9px] opacity-75">J</span>
          </button>
          <button
            type="button"
            onPointerDown={() => handleActionStart('heavyPunch')}
            onPointerUp={() => handleActionEnd('heavyPunch')}
            onPointerLeave={() => handleActionEnd('heavyPunch')}
            className="w-12 h-12 rounded-full bg-blue-700 active:bg-blue-500 font-bold text-xs text-white shadow-lg active:scale-95 transition-transform flex flex-col items-center justify-center"
          >
            <span>HP</span>
            <span className="text-[9px] opacity-75">U</span>
          </button>
          <button
            type="button"
            onPointerDown={() => handleActionStart('special1')}
            onPointerUp={() => handleActionEnd('special1')}
            onPointerLeave={() => handleActionEnd('special1')}
            className="w-12 h-12 rounded-full bg-purple-700 active:bg-purple-500 font-bold text-xs text-white shadow-lg active:scale-95 transition-transform flex flex-col items-center justify-center"
          >
            <span>SP 1</span>
            <span className="text-[9px] opacity-75">I</span>
          </button>
        </div>

        {/* Bottom Row: Kicks & Special 2 & Ultimate */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onPointerDown={() => handleActionStart('lightKick')}
            onPointerUp={() => handleActionEnd('lightKick')}
            onPointerLeave={() => handleActionEnd('lightKick')}
            className="w-12 h-12 rounded-full bg-amber-600 active:bg-amber-400 font-bold text-xs text-white shadow-lg active:scale-95 transition-transform flex flex-col items-center justify-center"
          >
            <span>LK</span>
            <span className="text-[9px] opacity-75">K</span>
          </button>
          <button
            type="button"
            onPointerDown={() => handleActionStart('heavyKick')}
            onPointerUp={() => handleActionEnd('heavyKick')}
            onPointerLeave={() => handleActionEnd('heavyKick')}
            className="w-12 h-12 rounded-full bg-amber-700 active:bg-amber-500 font-bold text-xs text-white shadow-lg active:scale-95 transition-transform flex flex-col items-center justify-center"
          >
            <span>HK</span>
            <span className="text-[9px] opacity-75">L</span>
          </button>
          <button
            type="button"
            onPointerDown={() => handleActionStart('special2')}
            onPointerUp={() => handleActionEnd('special2')}
            onPointerLeave={() => handleActionEnd('special2')}
            className="w-12 h-12 rounded-full bg-purple-800 active:bg-purple-600 font-bold text-xs text-white shadow-lg active:scale-95 transition-transform flex flex-col items-center justify-center"
          >
            <span>SP 2</span>
            <span className="text-[9px] opacity-75">O</span>
          </button>
          <button
            type="button"
            onPointerDown={() => handleActionStart('ultimate')}
            onPointerUp={() => handleActionEnd('ultimate')}
            onPointerLeave={() => handleActionEnd('ultimate')}
            className="w-12 h-12 rounded-full bg-red-600 active:bg-red-400 border-2 border-amber-400 font-bold text-xs text-white shadow-lg active:scale-95 transition-transform flex flex-col items-center justify-center"
          >
            <span>ULT</span>
            <span className="text-[9px] opacity-75">P</span>
          </button>
        </div>
      </div>
    </div>
  );
};
