import React, { useState } from 'react';
import { Swords, Trophy, BookOpen, Volume2, VolumeX, Shield, Play, Keyboard, Download, CheckCircle, ExternalLink } from 'lucide-react';
import { sound } from '../audio/soundEngine';

interface TitleScreenProps {
  onSelectMode: (mode: 'ARCADE' | 'VERSUS' | 'TRAINING') => void;
  onOpenDossier: () => void;
  onToggleSound: () => void;
  isMuted: boolean;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onSelectMode,
  onOpenDossier,
  onToggleSound,
  isMuted,
}) => {
  const [showControlsModal, setShowControlsModal] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);

  return (
    <div className="w-full h-full flex flex-col items-center justify-between p-6 bg-zinc-950 text-white relative scanlines overflow-hidden">
      {/* Top Header */}
      <header className="w-full max-w-5xl flex items-center justify-between z-10">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
          <span className="text-xs font-bold tracking-widest text-zinc-400 font-tech">
            ARCADE EDITION · 25 ORIGINAL LEGENDS
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              sound.playMenuBeep();
              setShowExportModal(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950/80 border border-emerald-600/70 hover:bg-emerald-900/80 text-xs font-tech text-emerald-300 font-bold transition-colors shadow-sm"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Download ZIP</span>
          </button>
          <button
            onClick={() => {
              sound.playMenuBeep();
              setShowControlsModal(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 hover:border-zinc-700 text-xs font-tech text-zinc-300 transition-colors"
          >
            <Keyboard className="w-4 h-4 text-amber-400" />
            <span>Controls Guide</span>
          </button>
          <button
            onClick={onToggleSound}
            className="p-2 rounded-lg bg-zinc-900 border border-zinc-800 hover:border-zinc-700 text-zinc-300 transition-colors"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-green-400" />}
          </button>
        </div>
      </header>

      {/* Hero Center Branding */}
      <div className="flex flex-col items-center text-center my-auto z-10 max-w-3xl">
        <div className="text-xs md:text-sm font-tech font-bold text-amber-400 tracking-[0.3em] uppercase mb-1">
          THE AUTHENTIC 1v1 MARTIAL ARTS FIGHTING GAME
        </div>
        <h1 className="text-6xl md:text-8xl font-black font-arcade tracking-wider leading-none text-transparent bg-clip-text bg-gradient-to-b from-white via-zinc-200 to-amber-400 drop-shadow-[0_10px_20px_rgba(245,158,11,0.2)]">
          WORLD STRIKE
        </h1>
        <div className="text-xl md:text-3xl font-bold font-arcade tracking-[0.25em] text-red-500 mt-1">
          MARTIAL LEGENDS
        </div>

        <p className="text-xs md:text-sm text-zinc-400 font-tech max-w-xl mt-3 leading-relaxed">
          Kyokushin Karate · Muay Thai · Burmese Lethwei · Wushu Sanda · Filipino Yaw-Yan.
          5 elite divisions. 25 distinct archetypes. One definitive champion.
        </p>

        {/* Game Mode Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 w-full mt-8">
          {/* Arcade Mode */}
          <button
            onClick={() => {
              sound.playMenuConfirm();
              onSelectMode('ARCADE');
            }}
            className="group p-4 rounded-xl bg-zinc-900/90 border border-zinc-800 hover:border-amber-500/80 hover:bg-zinc-850 text-left transition-all shadow-lg hover:scale-[1.02] flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mb-3 group-hover:bg-amber-500 group-hover:text-zinc-950 transition-colors text-amber-400">
                <Trophy className="w-5 h-5" />
              </div>
              <h2 className="text-lg font-bold font-arcade tracking-wide text-white group-hover:text-amber-300">
                ARCADE MODE
              </h2>
              <p className="text-xs text-zinc-400 mt-1 leading-snug">
                Battle through a 5-round international tournament ladder to claim the world title.
              </p>
            </div>
            <div className="mt-3 text-[10px] font-bold font-tech text-amber-400 uppercase tracking-wider flex items-center gap-1">
              <span>ENTER TOURNAMENT</span>
              <span>→</span>
            </div>
          </button>

          {/* Quick Versus */}
          <button
            onClick={() => {
              sound.playMenuConfirm();
              onSelectMode('VERSUS');
            }}
            className="group p-4 rounded-xl bg-zinc-900/90 border border-zinc-800 hover:border-red-500/80 hover:bg-zinc-850 text-left transition-all shadow-lg hover:scale-[1.02] flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-lg bg-red-500/10 border border-red-500/30 flex items-center justify-center mb-3 group-hover:bg-red-500 group-hover:text-white transition-colors text-red-400">
                <Swords className="w-5 h-5" />
              </div>
              <h2 className="text-lg font-bold font-arcade tracking-wide text-white group-hover:text-red-300">
                QUICK VERSUS
              </h2>
              <p className="text-xs text-zinc-400 mt-1 leading-snug">
                Immediate 1v1 match. Choose any two fighters, any stage, and fight CPU or Local 2-Player.
              </p>
            </div>
            <div className="mt-3 text-[10px] font-bold font-tech text-red-400 uppercase tracking-wider flex items-center gap-1">
              <span>FIGHT NOW</span>
              <span>→</span>
            </div>
          </button>

          {/* Training Dojo */}
          <button
            onClick={() => {
              sound.playMenuConfirm();
              onSelectMode('TRAINING');
            }}
            className="group p-4 rounded-xl bg-zinc-900/90 border border-zinc-800 hover:border-blue-500/80 hover:bg-zinc-850 text-left transition-all shadow-lg hover:scale-[1.02] flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-lg bg-blue-500/10 border border-blue-500/30 flex items-center justify-center mb-3 group-hover:bg-blue-500 group-hover:text-white transition-colors text-blue-400">
                <Shield className="w-5 h-5" />
              </div>
              <h2 className="text-lg font-bold font-arcade tracking-wide text-white group-hover:text-blue-300">
                TRAINING DOJO
              </h2>
              <p className="text-xs text-zinc-400 mt-1 leading-snug">
                Infinite health and super meter. Master combo links, frame timings, and special techniques.
              </p>
            </div>
            <div className="mt-3 text-[10px] font-bold font-tech text-blue-400 uppercase tracking-wider flex items-center gap-1">
              <span>ENTER DOJO</span>
              <span>→</span>
            </div>
          </button>
        </div>

        {/* Martial Arts Dossier Link */}
        <button
          onClick={() => {
            sound.playMenuConfirm();
            onOpenDossier();
          }}
          className="mt-4 flex items-center gap-2 px-4 py-2 rounded-lg bg-zinc-900/60 border border-zinc-800 hover:border-zinc-700 text-xs font-tech text-zinc-300 hover:text-white transition-colors"
        >
          <BookOpen className="w-4 h-4 text-amber-400" />
          <span>Explore 25-Fighter Martial Arts Dossier & Encyclopedia</span>
        </button>
      </div>

      {/* Footer Info */}
      <footer className="w-full max-w-5xl flex items-center justify-between text-[11px] text-zinc-500 font-tech z-10 border-t border-zinc-900 pt-3">
        <div>WORLD STRIKE · STRICTLY 1v1 ARCADE COMBAT</div>
        <div>READY FOR GITHUB & ANDROID PACKAGING</div>
      </footer>

      {/* Export / Download ZIP Modal */}
      {showExportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="bg-zinc-900 border border-zinc-700 w-full max-w-lg rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <div className="flex items-center gap-2">
                <Download className="w-5 h-5 text-emerald-400" />
                <h3 className="text-xl font-bold font-arcade tracking-wide text-white">
                  EXPORT FOR GITHUB & ANDROID
                </h3>
              </div>
              <button
                onClick={() => setShowExportModal(false)}
                className="text-zinc-400 hover:text-white text-xs font-tech p-1"
              >
                ✕ Close
              </button>
            </div>

            <p className="text-xs text-zinc-300 leading-relaxed font-tech">
              The full project source code is packaged into a clean ZIP archive containing all source files, the complete native Android project, and GitHub Actions workflow for automatic APK generation.
            </p>

            <div className="bg-zinc-950 p-3 rounded-lg border border-zinc-800 space-y-1.5 text-xs font-tech text-zinc-300">
              <div className="font-bold text-amber-400 mb-1">Archive Contents Verified:</div>
              <div className="flex items-center gap-1.5 text-emerald-400">
                <CheckCircle className="w-3.5 h-3.5" />
                <span><code className="text-white">src/</code> — 25 fighters, physics engine, canvas renderer, Web Audio SFX</span>
              </div>
              <div className="flex items-center gap-1.5 text-emerald-400">
                <CheckCircle className="w-3.5 h-3.5" />
                <span><code className="text-white">android/</code> — Gradle project, MainActivity.kt, Manifest, fullscreen theme</span>
              </div>
              <div className="flex items-center gap-1.5 text-emerald-400">
                <CheckCircle className="w-3.5 h-3.5" />
                <span><code className="text-white">.github/workflows/build-apk.yml</code> — CI/CD to build debug APK on GitHub</span>
              </div>
              <div className="flex items-center gap-1.5 text-emerald-400">
                <CheckCircle className="w-3.5 h-3.5" />
                <span><code className="text-white">scripts/</code> — build-android.js and package-zip.py</span>
              </div>
              <div className="flex items-center gap-1.5 text-emerald-400">
                <CheckCircle className="w-3.5 h-3.5" />
                <span><code className="text-white">package.json</code>, <code className="text-white">index.html</code>, <code className="text-white">README.md</code>, <code className="text-white">public/</code></span>
              </div>
            </div>

            {/* Direct Download Button */}
            <a
              href="/world-strike-martial-legends.zip"
              download="world-strike-martial-legends.zip"
              onClick={() => sound.playMenuConfirm()}
              className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-zinc-950 font-arcade text-xl font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 tracking-wider"
            >
              <Download className="w-5 h-5 text-zinc-950" />
              <span>DOWNLOAD COMPLETE PROJECT ZIP (92 KB)</span>
            </a>

            <div className="text-[11px] text-zinc-400 font-tech space-y-1 border-t border-zinc-800 pt-3">
              <div className="font-bold text-white">How to use on your phone:</div>
              <p>1. Tap the button above to download the ZIP directly to your phone's storage.</p>
              <p>2. Upload to GitHub via GitHub Mobile or the desktop site.</p>
              <p>3. GitHub Actions will automatically compile your installable <code className="text-amber-400">app-debug.apk</code> under the Actions tab!</p>
            </div>
          </div>
        </div>
      )}

      {/* Controls Modal */}
      {showControlsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-zinc-900 border border-zinc-700 w-full max-w-lg rounded-xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <h3 className="text-lg font-bold font-arcade tracking-wide text-amber-400">
                ARCADE CONTROLS GUIDE
              </h3>
              <button
                onClick={() => setShowControlsModal(false)}
                className="text-zinc-400 hover:text-white text-xs font-tech"
              >
                ✕ Close
              </button>
            </div>

            <div className="space-y-3 font-tech text-xs">
              <div>
                <div className="font-bold text-white mb-1">Player 1 (Keyboard):</div>
                <div className="grid grid-cols-2 gap-2 text-zinc-300 bg-zinc-950 p-2.5 rounded border border-zinc-800">
                  <div>Move: <span className="text-amber-400 font-mono font-bold">W A S D</span></div>
                  <div>Guard: <span className="text-amber-400 font-mono font-bold">Hold Back / Space</span></div>
                  <div>Light Punch: <span className="text-amber-400 font-mono font-bold">J</span></div>
                  <div>Heavy Punch: <span className="text-amber-400 font-mono font-bold">U</span></div>
                  <div>Light Kick: <span className="text-amber-400 font-mono font-bold">K</span></div>
                  <div>Heavy Kick: <span className="text-amber-400 font-mono font-bold">L</span></div>
                  <div>Special 1: <span className="text-purple-400 font-mono font-bold">I</span></div>
                  <div>Special 2: <span className="text-purple-400 font-mono font-bold">O</span></div>
                  <div className="col-span-2">Ultimate Finisher (100% Meter): <span className="text-red-400 font-mono font-bold">P</span></div>
                </div>
              </div>

              <div>
                <div className="font-bold text-white mb-1">Player 2 (Local 2-Player):</div>
                <div className="grid grid-cols-2 gap-2 text-zinc-300 bg-zinc-950 p-2.5 rounded border border-zinc-800">
                  <div>Move: <span className="text-cyan-400 font-mono font-bold">Arrow Keys</span></div>
                  <div>Punch / Kick: <span className="text-cyan-400 font-mono font-bold">NumPad 1, 2, 4, 5</span></div>
                  <div>Specials / Ult: <span className="text-cyan-400 font-mono font-bold">NumPad 6, 7, 8</span></div>
                </div>
              </div>

              <div>
                <div className="font-bold text-white mb-1">Touch & Mobile:</div>
                <p className="text-zinc-400">
                  Full on-screen arcade D-Pad and 6 responsive action buttons appear directly underneath the combat viewport.
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowControlsModal(false)}
              className="w-full py-2 bg-amber-500 text-zinc-950 font-bold rounded-lg text-xs font-tech hover:bg-amber-400 transition-colors"
            >
              GOT IT
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
