import React, { useState } from 'react';
import { ROSTER_DATA } from '../data/roster';
import { MartialArtDiscipline } from '../types/fighter';
import { ArrowLeft, BookOpen, Shield, Zap, Target } from 'lucide-react';
import { sound } from '../audio/soundEngine';

interface DossierViewProps {
  onBack: () => void;
}

export const DossierView: React.FC<DossierViewProps> = ({ onBack }) => {
  const [selectedDiscipline, setSelectedDiscipline] = useState<MartialArtDiscipline | 'ALL'>('ALL');
  const [activeFighterId, setActiveFighterId] = useState<string>(ROSTER_DATA[0].id);

  const disciplines: { id: MartialArtDiscipline | 'ALL'; label: string; desc: string }[] = [
    { id: 'ALL', label: 'ALL DISCIPLINES', desc: 'The 25 legendary martial artists of the World Strike tournament.' },
    { id: 'KYOKUSHIN', label: 'KYOKUSHIN', desc: 'Full-contact Japanese karate focusing on devastating low kicks, iron body conditioning, and crushing body strikes.' },
    { id: 'MUAY_THAI', label: 'MUAY THAI', desc: 'The art of eight limbs: technical push kicks (teeps), bone-cracking roundhouses, spearing knees, and slicing elbows.' },
    { id: 'LETHWEI', label: 'LETHWEI', desc: 'Traditional Burmese bare-knuckle combat known as the art of nine limbs, incorporating lethal headbutts and unmatched grit.' },
    { id: 'WUSHU_SANDA', label: 'WUSHU SANDA', desc: 'Modern Chinese combat sport integrating rapid striking, piston side kicks, kick-catches, and dynamic wrestling takedowns.' },
    { id: 'YAW_YAN', label: 'YAW-YAN', desc: 'Sayaw ng Kamatayan: Filipino indigenous kickboxing featuring feline crouching stances, downward 45-degree whip kicks, and bolo strikes.' },
  ];

  const filteredFighters = selectedDiscipline === 'ALL'
    ? ROSTER_DATA
    : ROSTER_DATA.filter((f) => f.discipline === selectedDiscipline);

  const activeFighter = ROSTER_DATA.find((f) => f.id === activeFighterId) || ROSTER_DATA[0];

  return (
    <div className="w-full h-full flex flex-col bg-zinc-950 text-white overflow-hidden scanlines">
      {/* Header */}
      <header className="px-6 py-3 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/70 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              sound.playMenuBeep();
              onBack();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-300 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </button>
          <div>
            <h1 className="text-xl font-bold font-arcade tracking-wider text-amber-400">
              MARTIAL ARTS DOSSIER
            </h1>
            <div className="text-[11px] text-zinc-400 font-tech">
              25 Original Fighters · 5 Disciplines · Technical Database
            </div>
          </div>
        </div>

        {/* Discipline Filter Tabs */}
        <div className="flex items-center gap-1 bg-zinc-900 p-1 rounded-lg border border-zinc-800">
          {disciplines.map((d) => (
            <button
              key={d.id}
              onClick={() => {
                sound.playMenuBeep();
                setSelectedDiscipline(d.id);
              }}
              className={`px-3 py-1 text-xs font-semibold rounded font-tech transition-colors ${
                selectedDiscipline === d.id
                  ? 'bg-amber-500 text-zinc-950 shadow'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              {d.label}
            </button>
          ))}
        </div>
      </header>

      {/* Main Layout */}
      <div className="flex-1 grid grid-cols-12 gap-4 p-4 overflow-hidden">
        {/* Left List: Fighters */}
        <div className="col-span-4 bg-zinc-900/60 border border-zinc-800 rounded-xl p-3 flex flex-col overflow-hidden">
          <div className="text-xs font-tech text-zinc-400 uppercase tracking-wider mb-2 px-1">
            Fighters ({filteredFighters.length})
          </div>
          <div className="flex-1 space-y-1.5 overflow-y-auto pr-1">
            {filteredFighters.map((f) => {
              const isSelected = f.id === activeFighterId;
              return (
                <button
                  key={f.id}
                  onClick={() => {
                    sound.playMenuBeep();
                    setActiveFighterId(f.id);
                  }}
                  className={`w-full p-2.5 rounded-lg border text-left flex items-center justify-between transition-all ${
                    isSelected
                      ? 'bg-amber-950/40 border-amber-500/80 shadow'
                      : 'bg-zinc-950/60 border-zinc-850 hover:bg-zinc-800/50 hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl">{f.flag}</span>
                    <div>
                      <div className="font-arcade text-base font-bold text-white tracking-wide">
                        {f.name}
                      </div>
                      <div className="text-[10px] text-zinc-400 font-tech">
                        {f.discipline.replace('_', ' ')} · {f.archetype}
                      </div>
                    </div>
                  </div>
                  <span className="text-xs italic text-amber-400 font-tech">
                    "{f.epithet}"
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Detail: Active Fighter Profile */}
        <div className="col-span-8 bg-zinc-900/60 border border-zinc-800 rounded-xl p-6 flex flex-col justify-between overflow-y-auto">
          <div className="space-y-4">
            {/* Fighter Header */}
            <div className="flex items-start justify-between border-b border-zinc-800 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-3xl">{activeFighter.flag}</span>
                  <span className="text-xs px-2 py-0.5 rounded bg-zinc-800 text-amber-400 font-tech uppercase font-bold">
                    {activeFighter.discipline.replace('_', ' ')}
                  </span>
                  <span className="text-xs text-zinc-400 font-tech">
                    {activeFighter.archetype}
                  </span>
                </div>
                <h2 className="text-4xl font-bold font-arcade tracking-wider text-white mt-1">
                  {activeFighter.name}
                </h2>
                <div className="text-sm italic text-amber-300 font-tech">
                  "{activeFighter.epithet}"
                </div>
              </div>

              {/* Attributes Radar Bars */}
              <div className="w-56 p-3 bg-zinc-950/80 rounded-lg border border-zinc-800 text-xs font-tech space-y-1.5">
                <div className="flex justify-between items-center text-zinc-400">
                  <span>POWER</span>
                  <span className="text-amber-400 font-bold">{activeFighter.attributes.power}/10</span>
                </div>
                <div className="flex justify-between items-center text-zinc-400">
                  <span>SPEED</span>
                  <span className="text-amber-400 font-bold">{activeFighter.attributes.speed}/10</span>
                </div>
                <div className="flex justify-between items-center text-zinc-400">
                  <span>DEFENSE</span>
                  <span className="text-amber-400 font-bold">{activeFighter.attributes.defense}/10</span>
                </div>
                <div className="flex justify-between items-center text-zinc-400">
                  <span>RANGE</span>
                  <span className="text-amber-400 font-bold">{activeFighter.attributes.range}/10</span>
                </div>
                <div className="flex justify-between items-center text-zinc-400">
                  <span>TECHNIQUE</span>
                  <span className="text-amber-400 font-bold">{activeFighter.attributes.technique}/10</span>
                </div>
              </div>
            </div>

            {/* Philosophy & Biography */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-zinc-950/60 rounded-lg border border-zinc-850">
                <div className="text-xs font-bold text-amber-400 uppercase tracking-wider font-tech mb-1">
                  Martial Philosophy
                </div>
                <blockquote className="text-sm italic text-zinc-200">
                  "{activeFighter.quote}"
                </blockquote>
                <div className="mt-3 text-xs font-bold text-zinc-400 uppercase tracking-wider font-tech mb-1">
                  Victory Proclamation
                </div>
                <div className="text-xs text-zinc-300 italic">
                  "{activeFighter.winQuote}"
                </div>
              </div>

              <div className="p-4 bg-zinc-950/60 rounded-lg border border-zinc-850">
                <div className="text-xs font-bold text-amber-400 uppercase tracking-wider font-tech mb-1">
                  Fighter Background
                </div>
                <p className="text-xs text-zinc-300 leading-relaxed">
                  {activeFighter.bio}
                </p>
              </div>
            </div>

            {/* Moveset Breakdown */}
            <div>
              <div className="text-xs font-bold text-zinc-400 uppercase tracking-wider font-tech mb-2">
                Special Techniques & Ultimate Execution
              </div>
              <div className="grid grid-cols-3 gap-3">
                {/* Special 1 */}
                <div className="p-3 bg-zinc-950/80 rounded-lg border border-zinc-800 flex flex-col justify-between">
                  <div>
                    <div className="text-xs font-bold text-amber-300 flex items-center gap-1 font-tech">
                      <Zap className="w-3.5 h-3.5 text-amber-400" />
                      {activeFighter.moves.special1.name}
                    </div>
                    <div className="text-[10px] text-zinc-400 font-mono mt-0.5">
                      {activeFighter.moves.special1.command} [I]
                    </div>
                    <p className="text-[11px] text-zinc-300 mt-2 leading-snug">
                      {activeFighter.moves.special1.description}
                    </p>
                  </div>
                  <div className="mt-2 text-[10px] text-zinc-400 font-mono border-t border-zinc-800 pt-1.5 flex justify-between">
                    <span>DMG: {activeFighter.moves.special1.damage}</span>
                    <span className="text-cyan-400">{activeFighter.moves.special1.hitType}</span>
                  </div>
                </div>

                {/* Special 2 */}
                <div className="p-3 bg-zinc-950/80 rounded-lg border border-zinc-800 flex flex-col justify-between">
                  <div>
                    <div className="text-xs font-bold text-amber-300 flex items-center gap-1 font-tech">
                      <Target className="w-3.5 h-3.5 text-amber-400" />
                      {activeFighter.moves.special2.name}
                    </div>
                    <div className="text-[10px] text-zinc-400 font-mono mt-0.5">
                      {activeFighter.moves.special2.command} [O]
                    </div>
                    <p className="text-[11px] text-zinc-300 mt-2 leading-snug">
                      {activeFighter.moves.special2.description}
                    </p>
                  </div>
                  <div className="mt-2 text-[10px] text-zinc-400 font-mono border-t border-zinc-800 pt-1.5 flex justify-between">
                    <span>DMG: {activeFighter.moves.special2.damage}</span>
                    <span className="text-cyan-400">{activeFighter.moves.special2.hitType}</span>
                  </div>
                </div>

                {/* Ultimate */}
                <div className="p-3 bg-red-950/40 rounded-lg border border-red-800/50 flex flex-col justify-between">
                  <div>
                    <div className="text-xs font-bold text-red-300 flex items-center gap-1 font-tech">
                      <Shield className="w-3.5 h-3.5 text-red-400" />
                      {activeFighter.moves.ultimate.name}
                    </div>
                    <div className="text-[10px] text-red-400/80 font-mono mt-0.5">
                      100% Super Gauge [P]
                    </div>
                    <p className="text-[11px] text-zinc-300 mt-2 leading-snug">
                      {activeFighter.moves.ultimate.description}
                    </p>
                  </div>
                  <div className="mt-2 text-[10px] text-red-300 font-mono border-t border-red-900/50 pt-1.5 flex justify-between">
                    <span>DMG: {activeFighter.moves.ultimate.damage}</span>
                    <span className="text-cyan-400">{activeFighter.moves.ultimate.hitType}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
