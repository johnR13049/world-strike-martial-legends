import React, { useState } from 'react';
import { FighterData, StageData } from '../types/fighter';
import { ROSTER_DATA } from '../data/roster';
import { STAGES_DATA } from '../data/stages';
import { sound } from '../audio/soundEngine';
import { Swords, Shuffle, ArrowLeft, Volume2, VolumeX, Shield, Zap, Target } from 'lucide-react';

interface CharacterSelectProps {
  mode: 'ARCADE' | 'VERSUS' | 'TRAINING';
  isP2Human: boolean;
  difficulty: 'EASY' | 'MEDIUM' | 'HARD' | 'MASTER';
  onStartFight: (p1: FighterData, p2: FighterData, stage: StageData) => void;
  onBack: () => void;
  onToggleSound: () => void;
  isMuted: boolean;
}

export const CharacterSelect: React.FC<CharacterSelectProps> = ({
  mode,
  isP2Human,
  difficulty,
  onStartFight,
  onBack,
  onToggleSound,
  isMuted,
}) => {
  const [selectedP1Index, setSelectedP1Index] = useState<number>(0);
  const [selectedP2Index, setSelectedP2Index] = useState<number>(5); // Default to Prasert for P2
  const [p1Locked, setP1Locked] = useState<boolean>(false);
  const [p2Locked, setP2Locked] = useState<boolean>(mode !== 'VERSUS' || !isP2Human);
  const [selectedStageIndex, setSelectedStageIndex] = useState<number>(0);

  const p1 = ROSTER_DATA[selectedP1Index];
  const p2 = ROSTER_DATA[selectedP2Index];
  const stage = STAGES_DATA[selectedStageIndex];

  const handleSelectFighter = (index: number) => {
    sound.playMenuBeep();
    if (!p1Locked) {
      setSelectedP1Index(index);
    } else if (isP2Human && !p2Locked) {
      setSelectedP2Index(index);
    }
  };

  const handleRandomize = () => {
    sound.playMenuBeep();
    const randP1 = Math.floor(Math.random() * ROSTER_DATA.length);
    setSelectedP1Index(randP1);
    if (!isP2Human) {
      let randP2 = Math.floor(Math.random() * ROSTER_DATA.length);
      while (randP2 === randP1) randP2 = Math.floor(Math.random() * ROSTER_DATA.length);
      setSelectedP2Index(randP2);
    }
  };

  const handleConfirm = () => {
    if (!p1Locked) {
      sound.playMenuConfirm();
      setP1Locked(true);
      if (isP2Human) {
        // Now pick P2
        return;
      }
    }
    // Start Fight
    sound.announce('Ready');
    onStartFight(p1, p2, stage);
  };

  const disciplineHeaders = [
    { title: 'KYOKUSHIN', color: '#e2e8f0', bg: 'bg-zinc-800' },
    { title: 'MUAY THAI', color: '#facc15', bg: 'bg-amber-950/60' },
    { title: 'LETHWEI', color: '#ef4444', bg: 'bg-red-950/60' },
    { title: 'WUSHU SANDA', color: '#38bdf8', bg: 'bg-sky-950/60' },
    { title: 'YAW-YAN', color: '#f97316', bg: 'bg-orange-950/60' },
  ];

  return (
    <div className="w-full h-full flex flex-col bg-zinc-950 text-white overflow-hidden scanlines relative">
      {/* Top Header */}
      <header className="px-6 py-3 border-b border-zinc-800/80 flex items-center justify-between bg-zinc-900/60 backdrop-blur-md z-10">
        <div className="flex items-center gap-4">
          <button
            onClick={onBack}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-300 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Main Menu</span>
          </button>
          <div>
            <h1 className="text-xl font-bold font-arcade tracking-wider text-amber-400">
              SELECT YOUR FIGHTER
            </h1>
            <div className="text-[11px] text-zinc-400 font-tech">
              MODE: <span className="text-white">{mode}</span> · {isP2Human ? 'LOCAL 2-PLAYER' : `CPU (${difficulty})`}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleRandomize}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-300 transition-colors"
          >
            <Shuffle className="w-4 h-4 text-amber-400" />
            <span>Random</span>
          </button>
          <button
            onClick={onToggleSound}
            className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-green-400" />}
          </button>
        </div>
      </header>

      {/* Main Selection Area */}
      <div className="flex-1 grid grid-cols-12 gap-4 p-4 overflow-hidden">
        {/* Left Column: P1 Fighter Showcase */}
        <div className="col-span-3 bg-zinc-900/70 border border-zinc-800/90 rounded-xl p-4 flex flex-col justify-between overflow-hidden shadow-xl">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-bold tracking-wider bg-red-600/30 text-red-400 border border-red-500/40 font-tech">
                PLAYER 1
              </span>
              <span className="text-2xl">{p1.flag}</span>
            </div>

            <h2 className="text-2xl font-bold font-arcade tracking-wide text-white uppercase leading-none">
              {p1.name}
            </h2>
            <div className="text-xs text-amber-400 font-medium italic mt-0.5 font-tech">
              "{p1.epithet}"
            </div>

            <div className="mt-2 text-[11px] text-zinc-400 flex items-center gap-2">
              <span className="font-bold text-zinc-200">{p1.discipline.replace('_', ' ')}</span>
              <span>·</span>
              <span>{p1.archetype}</span>
            </div>

            <div className="mt-3 p-2.5 rounded bg-zinc-950/70 border border-zinc-800 text-[11px] text-zinc-300 italic">
              "{p1.quote}"
            </div>

            {/* Stats Attributes */}
            <div className="mt-4 space-y-1.5 font-tech text-xs">
              <div className="flex justify-between items-center text-zinc-400">
                <span>POWER</span>
                <div className="flex gap-1">
                  {Array.from({ length: 10 }).map((_, i) => (
                    <div
                      key={i}
                      className={`w-2.5 h-2 rounded-xs ${i < p1.attributes.power ? 'bg-red-500' : 'bg-zinc-800'}`}
                    />
                  ))}
                </div>
              </div>
              <div className="flex justify-between items-center text-zinc-400">
                <span>SPEED</span>
                <div className="flex gap-1">
                  {Array.from({ length: 10 }).map((_, i) => (
                    <div
                      key={i}
                      className={`w-2.5 h-2 rounded-xs ${i < p1.attributes.speed ? 'bg-amber-400' : 'bg-zinc-800'}`}
                    />
                  ))}
                </div>
              </div>
              <div className="flex justify-between items-center text-zinc-400">
                <span>DEFENSE</span>
                <div className="flex gap-1">
                  {Array.from({ length: 10 }).map((_, i) => (
                    <div
                      key={i}
                      className={`w-2.5 h-2 rounded-xs ${i < p1.attributes.defense ? 'bg-blue-400' : 'bg-zinc-800'}`}
                    />
                  ))}
                </div>
              </div>
              <div className="flex justify-between items-center text-zinc-400">
                <span>RANGE</span>
                <div className="flex gap-1">
                  {Array.from({ length: 10 }).map((_, i) => (
                    <div
                      key={i}
                      className={`w-2.5 h-2 rounded-xs ${i < p1.attributes.range ? 'bg-emerald-400' : 'bg-zinc-800'}`}
                    />
                  ))}
                </div>
              </div>
              <div className="flex justify-between items-center text-zinc-400">
                <span>TECHNIQUE</span>
                <div className="flex gap-1">
                  {Array.from({ length: 10 }).map((_, i) => (
                    <div
                      key={i}
                      className={`w-2.5 h-2 rounded-xs ${i < p1.attributes.technique ? 'bg-purple-400' : 'bg-zinc-800'}`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Special Moves Snippet */}
          <div className="border-t border-zinc-800/80 pt-3 space-y-1.5">
            <div className="text-[10px] text-zinc-400 uppercase tracking-wider font-tech">Signature Moves</div>
            <div className="text-xs text-zinc-300 flex items-center justify-between">
              <span className="truncate">{p1.moves.special1.name}</span>
              <span className="text-[10px] text-zinc-500 font-mono">I</span>
            </div>
            <div className="text-xs text-zinc-300 flex items-center justify-between">
              <span className="truncate">{p1.moves.special2.name}</span>
              <span className="text-[10px] text-zinc-500 font-mono">O</span>
            </div>
            <div className="text-xs text-red-400 font-semibold flex items-center justify-between">
              <span className="truncate">ULT: {p1.moves.ultimate.name}</span>
              <span className="text-[10px] text-red-500 font-mono">P</span>
            </div>
          </div>
        </div>

        {/* Center: 5x5 Roster Grid (25 Fighters) */}
        <div className="col-span-6 flex flex-col gap-2 overflow-y-auto pr-1">
          {disciplineHeaders.map((dh, rowIdx) => {
            const rowFighters = ROSTER_DATA.slice(rowIdx * 5, rowIdx * 5 + 5);
            return (
              <div key={dh.title} className="flex flex-col gap-1">
                <div className="text-[10px] font-bold tracking-wider font-tech text-zinc-400 px-1">
                  {dh.title}
                </div>
                <div className="grid grid-cols-5 gap-2">
                  {rowFighters.map((f, colIdx) => {
                    const idx = rowIdx * 5 + colIdx;
                    const isP1 = selectedP1Index === idx;
                    const isP2 = selectedP2Index === idx;

                    return (
                      <button
                        key={f.id}
                        onClick={() => handleSelectFighter(idx)}
                        className={`group relative h-20 rounded-lg p-2 flex flex-col justify-between text-left transition-all border ${
                          isP1 && isP2
                            ? 'border-purple-500 bg-purple-950/40 ring-2 ring-purple-500 scale-[1.02]'
                            : isP1
                            ? 'border-amber-400 bg-amber-950/40 ring-2 ring-amber-400 scale-[1.02]'
                            : isP2
                            ? 'border-blue-500 bg-blue-950/40 ring-2 ring-blue-500 scale-[1.02]'
                            : 'border-zinc-800 bg-zinc-900/60 hover:border-zinc-600 hover:bg-zinc-800/80'
                        }`}
                      >
                        {/* Status Tags */}
                        <div className="flex items-center justify-between w-full">
                          <span className="text-sm">{f.flag}</span>
                          <div className="flex gap-1">
                            {isP1 && (
                              <span className="text-[9px] font-bold px-1 rounded bg-amber-500 text-zinc-950">
                                P1
                              </span>
                            )}
                            {isP2 && (
                              <span className="text-[9px] font-bold px-1 rounded bg-blue-500 text-white">
                                {isP2Human ? 'P2' : 'CPU'}
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Name & Archetype */}
                        <div>
                          <div className="font-arcade text-sm font-bold text-white tracking-wide truncate">
                            {f.name}
                          </div>
                          <div className="text-[9px] text-zinc-400 truncate font-tech">
                            {f.archetype}
                          </div>
                        </div>

                        {/* Style color accent dot */}
                        <div
                          className="absolute bottom-1.5 right-1.5 w-1.5 h-1.5 rounded-full"
                          style={{ backgroundColor: f.visuals.trailColor }}
                        />
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Column: P2 Showcase & Stage Selector */}
        <div className="col-span-3 bg-zinc-900/70 border border-zinc-800/90 rounded-xl p-4 flex flex-col justify-between overflow-hidden shadow-xl">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-bold tracking-wider bg-blue-600/30 text-blue-400 border border-blue-500/40 font-tech">
                {isP2Human ? 'PLAYER 2' : 'OPPONENT (CPU)'}
              </span>
              <span className="text-2xl">{p2.flag}</span>
            </div>

            <h2 className="text-2xl font-bold font-arcade tracking-wide text-white uppercase leading-none">
              {p2.name}
            </h2>
            <div className="text-xs text-blue-400 font-medium italic mt-0.5 font-tech">
              "{p2.epithet}"
            </div>

            <div className="mt-2 text-[11px] text-zinc-400 flex items-center gap-2">
              <span className="font-bold text-zinc-200">{p2.discipline.replace('_', ' ')}</span>
              <span>·</span>
              <span>{p2.archetype}</span>
            </div>

            <div className="mt-3 p-2.5 rounded bg-zinc-950/70 border border-zinc-800 text-[11px] text-zinc-300 italic">
              "{p2.quote}"
            </div>

            {/* Stage Selector */}
            <div className="mt-4 border-t border-zinc-800 pt-3">
              <div className="text-[10px] text-zinc-400 uppercase tracking-wider font-tech mb-1.5">
                Fighting Arena
              </div>
              <div className="flex items-center gap-2">
                <select
                  value={selectedStageIndex}
                  onChange={(e) => {
                    sound.playMenuBeep();
                    setSelectedStageIndex(Number(e.target.value));
                  }}
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400 font-tech"
                >
                  {STAGES_DATA.map((s, idx) => (
                    <option key={s.id} value={idx}>
                      {s.name} ({s.country})
                    </option>
                  ))}
                </select>
              </div>
              <div className="text-[11px] text-zinc-400 mt-1 font-tech">
                {stage.location} · {stage.country}
              </div>
            </div>
          </div>

          {/* Confirm & Start Button */}
          <div className="mt-4 pt-3 border-t border-zinc-800">
            <button
              onClick={handleConfirm}
              className="w-full py-3 bg-gradient-to-r from-amber-500 to-red-600 hover:from-amber-400 hover:to-red-500 text-zinc-950 font-arcade text-xl font-bold rounded-lg shadow-lg active:scale-98 transition-all flex items-center justify-center gap-2 tracking-wider"
            >
              <Swords className="w-5 h-5 text-zinc-950" />
              <span>COMMENCE BATTLE</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
