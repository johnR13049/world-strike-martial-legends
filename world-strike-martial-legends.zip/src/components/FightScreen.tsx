import React, { useEffect, useRef, useState } from 'react';
import { FightEngine } from '../game/engine';
import { FightRenderer } from '../game/renderer';
import { FighterData, StageData } from '../types/fighter';
import { ArcadeControls } from './ArcadeControls';
import { MoveListModal } from './MoveListModal';
import { VictoryModal } from './VictoryModal';
import { sound } from '../audio/soundEngine';
import { Pause, Play, RotateCcw, Users, Home, BookOpen, Volume2, VolumeX, Smartphone } from 'lucide-react';

interface FightScreenProps {
  p1Data: FighterData;
  p2Data: FighterData;
  stage: StageData;
  mode: 'ARCADE' | 'VERSUS' | 'TRAINING';
  isP2Human: boolean;
  difficulty: 'EASY' | 'MEDIUM' | 'HARD' | 'MASTER';
  arcadeStage: number;
  totalArcadeStages: number;
  onMatchComplete: (winnerIsP1: boolean) => void;
  onNextOpponent: () => void;
  onSelectFighter: () => void;
  onMainMenu: () => void;
  onToggleSound: () => void;
  isMuted: boolean;
}

export const FightScreen: React.FC<FightScreenProps> = ({
  p1Data,
  p2Data,
  stage,
  mode,
  isP2Human,
  difficulty,
  arcadeStage,
  totalArcadeStages,
  onMatchComplete,
  onNextOpponent,
  onSelectFighter,
  onMainMenu,
  onToggleSound,
  isMuted,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<FightEngine | null>(null);
  const rendererRef = useRef<FightRenderer | null>(null);

  const [isPaused, setIsPaused] = useState(false);
  const [showMoveList, setShowMoveList] = useState(false);
  const [showTouchControls, setShowTouchControls] = useState(true);
  const [isMatchOver, setIsMatchOver] = useState(false);
  const [matchWinner, setMatchWinner] = useState<1 | 2>(1);

  // Initialize engine & renderer
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    canvas.width = 1200;
    canvas.height = 600;

    const engine = new FightEngine(p1Data, p2Data, stage, mode, isP2Human, difficulty);
    const renderer = new FightRenderer(canvas);

    engineRef.current = engine;
    rendererRef.current = renderer;

    let animationFrameId: number;
    let lastTime = performance.now();

    const loop = (currentTime: number) => {
      const deltaTime = (currentTime - lastTime) / 1000;
      lastTime = currentTime;

      if (!isPaused) {
        engine.update(deltaTime);
      }
      renderer.render(engine);

      // Check match finished
      if (engine.state.matchState === 'MATCH_OVER' && !isMatchOver) {
        setIsMatchOver(true);
        setMatchWinner(engine.p1.roundsWon >= engine.state.maxRounds ? 1 : 2);
      }

      animationFrameId = requestAnimationFrame(loop);
    };

    animationFrameId = requestAnimationFrame(loop);

    // Keyboard handlers
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Escape') {
        setIsPaused((prev) => !prev);
        return;
      }
      if (isPaused) return;

      const p1In = engine.p1Inputs;
      const p2In = engine.p2Inputs;

      // P1 Inputs
      if (e.code === 'KeyA') p1In.left = true;
      if (e.code === 'KeyD') p1In.right = true;
      if (e.code === 'KeyW') p1In.up = true;
      if (e.code === 'KeyS') p1In.down = true;
      if (e.code === 'Space') p1In.guard = true;
      if (e.code === 'KeyJ') p1In.lightPunch = true;
      if (e.code === 'KeyU') p1In.heavyPunch = true;
      if (e.code === 'KeyK') p1In.lightKick = true;
      if (e.code === 'KeyL') p1In.heavyKick = true;
      if (e.code === 'KeyI') p1In.special1 = true;
      if (e.code === 'KeyO') p1In.special2 = true;
      if (e.code === 'KeyP') p1In.ultimate = true;

      // P2 Inputs (if Local 2P)
      if (isP2Human) {
        if (e.code === 'ArrowLeft') p2In.left = true;
        if (e.code === 'ArrowRight') p2In.right = true;
        if (e.code === 'ArrowUp') p2In.up = true;
        if (e.code === 'ArrowDown') p2In.down = true;
        if (e.code === 'Numpad0' || e.code === 'KeyM') p2In.guard = true;
        if (e.code === 'Numpad4' || e.code === 'Digit7') p2In.lightPunch = true;
        if (e.code === 'Numpad7' || e.code === 'Digit8') p2In.heavyPunch = true;
        if (e.code === 'Numpad1' || e.code === 'Digit9') p2In.lightKick = true;
        if (e.code === 'Numpad2' || e.code === 'Digit0') p2In.heavyKick = true;
        if (e.code === 'Numpad5' || e.code === 'Minus') p2In.special1 = true;
        if (e.code === 'Numpad6' || e.code === 'Equal') p2In.special2 = true;
        if (e.code === 'Numpad3' || e.code === 'Backspace') p2In.ultimate = true;
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const p1In = engine.p1Inputs;
      const p2In = engine.p2Inputs;

      if (e.code === 'KeyA') p1In.left = false;
      if (e.code === 'KeyD') p1In.right = false;
      if (e.code === 'KeyW') p1In.up = false;
      if (e.code === 'KeyS') p1In.down = false;
      if (e.code === 'Space') p1In.guard = false;
      if (e.code === 'KeyJ') p1In.lightPunch = false;
      if (e.code === 'KeyU') p1In.heavyPunch = false;
      if (e.code === 'KeyK') p1In.lightKick = false;
      if (e.code === 'KeyL') p1In.heavyKick = false;
      if (e.code === 'KeyI') p1In.special1 = false;
      if (e.code === 'KeyO') p1In.special2 = false;
      if (e.code === 'KeyP') p1In.ultimate = false;

      if (isP2Human) {
        if (e.code === 'ArrowLeft') p2In.left = false;
        if (e.code === 'ArrowRight') p2In.right = false;
        if (e.code === 'ArrowUp') p2In.up = false;
        if (e.code === 'ArrowDown') p2In.down = false;
        if (e.code === 'Numpad0' || e.code === 'KeyM') p2In.guard = false;
        if (e.code === 'Numpad4' || e.code === 'Digit7') p2In.lightPunch = false;
        if (e.code === 'Numpad7' || e.code === 'Digit8') p2In.heavyPunch = false;
        if (e.code === 'Numpad1' || e.code === 'Digit9') p2In.lightKick = false;
        if (e.code === 'Numpad2' || e.code === 'Digit0') p2In.heavyKick = false;
        if (e.code === 'Numpad5' || e.code === 'Minus') p2In.special1 = false;
        if (e.code === 'Numpad6' || e.code === 'Equal') p2In.special2 = false;
        if (e.code === 'Numpad3' || e.code === 'Backspace') p2In.ultimate = false;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      sound.stopBgm();
    };
  }, [p1Data, p2Data, stage, mode, isP2Human, difficulty]);

  const handleRestartMatch = () => {
    setIsPaused(false);
    setIsMatchOver(false);
    if (canvasRef.current) {
      engineRef.current = new FightEngine(p1Data, p2Data, stage, mode, isP2Human, difficulty);
      rendererRef.current = new FightRenderer(canvasRef.current);
    }
  };

  return (
    <div className="w-full h-full flex flex-col bg-zinc-950 text-white overflow-hidden scanlines relative">
      {/* Top Utility Bar */}
      <header className="px-4 py-2 border-b border-zinc-800/80 flex items-center justify-between bg-zinc-900/60 backdrop-blur-md z-10">
        <div className="flex items-center gap-3">
          <span className="font-arcade text-lg tracking-wider text-amber-400">
            WORLD STRIKE
          </span>
          <span className="text-zinc-600">·</span>
          <span className="text-xs font-tech text-zinc-300">
            {stage.name} ({stage.location})
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowMoveList(true)}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-xs font-tech text-zinc-300 transition-colors"
          >
            <BookOpen className="w-3.5 h-3.5 text-amber-400" />
            <span>Move List</span>
          </button>
          <button
            onClick={() => setShowTouchControls((prev) => !prev)}
            className="p-1.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors"
            title="Toggle Touch Controls"
          >
            <Smartphone className="w-4 h-4 text-purple-400" />
          </button>
          <button
            onClick={onToggleSound}
            className="p-1.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-green-400" />}
          </button>
          <button
            onClick={() => setIsPaused((prev) => !prev)}
            className="flex items-center gap-1 px-3 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-xs font-tech font-bold text-white transition-colors"
          >
            {isPaused ? <Play className="w-3.5 h-3.5 text-amber-400" /> : <Pause className="w-3.5 h-3.5" />}
            <span>{isPaused ? 'Resume' : 'Pause'}</span>
          </button>
        </div>
      </header>

      {/* Combat Viewport Frame */}
      <div className="flex-1 w-full flex items-center justify-center p-2 relative overflow-hidden bg-black">
        <canvas
          ref={canvasRef}
          className="w-full max-w-[1200px] aspect-[2/1] max-h-[70vh] rounded-lg shadow-2xl border border-zinc-800 object-contain bg-zinc-950"
        />
      </div>

      {/* On-Screen Touch / Mouse Controls */}
      {showTouchControls && engineRef.current && (
        <ArcadeControls engine={engineRef.current} />
      )}

      {/* Pause Menu Modal */}
      {isPaused && (
        <div className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-zinc-900 border border-zinc-700 w-full max-w-sm rounded-xl p-6 shadow-2xl space-y-3 font-tech text-center">
            <h3 className="text-2xl font-bold font-arcade tracking-wider text-amber-400">
              GAME PAUSED
            </h3>
            <div className="space-y-2 pt-2">
              <button
                onClick={() => setIsPaused(false)}
                className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold rounded-lg transition-colors"
              >
                Resume Battle
              </button>
              <button
                onClick={() => {
                  setShowMoveList(true);
                  setIsPaused(false);
                }}
                className="w-full py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white font-semibold rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <BookOpen className="w-4 h-4 text-amber-400" />
                <span>Command Move List</span>
              </button>
              <button
                onClick={handleRestartMatch}
                className="w-full py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white font-semibold rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-4 h-4 text-red-400" />
                <span>Restart Round</span>
              </button>
              <button
                onClick={onSelectFighter}
                className="w-full py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white font-semibold rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <Users className="w-4 h-4 text-blue-400" />
                <span>Fighter Select</span>
              </button>
              <button
                onClick={onMainMenu}
                className="w-full py-2 bg-zinc-950 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <Home className="w-4 h-4" />
                <span>Quit to Main Menu</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Move List Modal */}
      {showMoveList && (
        <MoveListModal
          fighter={p1Data}
          onClose={() => setShowMoveList(false)}
        />
      )}

      {/* Victory / Result Modal */}
      {isMatchOver && engineRef.current && (
        <VictoryModal
          winner={matchWinner === 1 ? engineRef.current.p1 : engineRef.current.p2}
          loser={matchWinner === 1 ? engineRef.current.p2 : engineRef.current.p1}
          isPerfect={engineRef.current.state.isPerfect}
          mode={mode}
          arcadeStage={arcadeStage}
          totalArcadeStages={totalArcadeStages}
          onRematch={handleRestartMatch}
          onNextOpponent={onNextOpponent}
          onSelectFighter={onSelectFighter}
          onMainMenu={onMainMenu}
        />
      )}
    </div>
  );
};
