import { FightEngine, FighterEntity } from './engine';
import { ParticleEffect } from '../types/fighter';

export class FightRenderer {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
  }

  public render(engine: FightEngine) {
    const ctx = this.ctx;
    const width = this.canvas.width;
    const height = this.canvas.height;

    // Apply Screen Shake
    ctx.save();
    if (engine.state.shakeTime > 0) {
      const intensity = engine.state.shakeIntensity;
      const offsetX = (Math.random() - 0.5) * intensity * 2;
      const offsetY = (Math.random() - 0.5) * intensity * 2;
      ctx.translate(offsetX, offsetY);
    }

    // Camera Transformations
    ctx.save();
    const zoom = engine.state.cameraZoom;
    const camX = engine.state.cameraX;
    ctx.translate(width / 2, height / 2);
    ctx.scale(zoom, zoom);
    ctx.translate(-camX, -height / 2);

    // 1. Render Stage Background & Scenery
    this.renderStage(engine);

    // 2. Render Fighters' Shadows
    this.renderShadow(engine.p1);
    this.renderShadow(engine.p2);

    // 3. Render Fighters
    this.renderFighter(engine.p1, engine);
    this.renderFighter(engine.p2, engine);

    // 4. Render Particles
    this.renderParticles(engine.state.particles);

    // 5. Render Ultimate Speedlines & Flash
    if (engine.state.superFlashAlpha > 0) {
      this.renderSuperEffect(engine);
    }

    ctx.restore(); // End Camera space

    // 6. Render HUD, Announcements, Combos, and Timers (in Screen space)
    this.renderHUD(engine);

    ctx.restore(); // End Screen shake
  }

  // ===================== STAGE BACKGROUND RENDERING =====================

  private renderStage(engine: FightEngine) {
    const ctx = this.ctx;
    const stage = engine.state.currentStage;
    const arenaW = engine.ARENA_WIDTH;
    const groundY = engine.GROUND_Y;

    // Sky / Back wall gradient
    const skyGrad = ctx.createLinearGradient(0, 0, 0, groundY);
    skyGrad.addColorStop(0, stage.bgSkyGradient[0]);
    skyGrad.addColorStop(1, stage.bgSkyGradient[1]);
    ctx.fillStyle = skyGrad;
    ctx.fillRect(-200, 0, arenaW + 400, groundY);

    // Architectural features based on stage
    if (stage.bgArchitectureType === 'japan_dojo') {
      // Traditional Japanese Dojo: Shoji frames, wood pillars, banners
      ctx.fillStyle = '#1c1917';
      for (let x = -100; x < arenaW + 100; x += 180) {
        ctx.fillRect(x, 60, 24, groundY - 60); // Wooden pillars
        ctx.fillStyle = 'rgba(254, 243, 199, 0.08)';
        ctx.fillRect(x + 24, 80, 156, 320); // Shoji paper glow
        ctx.fillStyle = '#1c1917';
      }
      // Top beam
      ctx.fillStyle = '#292524';
      ctx.fillRect(-200, 50, arenaW + 400, 30);
      // Traditional Calligraphy Banners
      ctx.fillStyle = '#78350f';
      ctx.fillRect(arenaW / 2 - 120, 90, 240, 160);
      ctx.fillStyle = '#fef3c7';
      ctx.font = 'bold 36px "Chakra Petch", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('一 撃 必 殺', arenaW / 2, 175);
      ctx.font = '14px sans-serif';
      ctx.fillText('SHIN KYOKUSHIN HONBU', arenaW / 2, 215);
    } else if (stage.bgArchitectureType === 'thai_stadium') {
      // Bangkok Stadium: Ring lights, neon banners, crowd silhouette
      ctx.fillStyle = '#172554';
      ctx.fillRect(-200, 80, arenaW + 400, 120);
      // Ring Spotlight Beams
      const beamGrad = ctx.createLinearGradient(arenaW / 2, 0, arenaW / 2, groundY);
      beamGrad.addColorStop(0, 'rgba(56, 189, 248, 0.25)');
      beamGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = beamGrad;
      ctx.beginPath();
      ctx.moveTo(arenaW / 2 - 200, 0);
      ctx.lineTo(arenaW / 2 + 200, 0);
      ctx.lineTo(arenaW / 2 + 500, groundY);
      ctx.lineTo(arenaW / 2 - 500, groundY);
      ctx.fill();
      // Stadium Ring Ropes
      [groundY - 140, groundY - 95, groundY - 50].forEach((ropeY, idx) => {
        ctx.strokeStyle = idx === 0 ? '#ef4444' : idx === 1 ? '#ffffff' : '#3b82f6';
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.moveTo(-100, ropeY);
        ctx.lineTo(arenaW + 100, ropeY);
        ctx.stroke();
      });
    } else if (stage.bgArchitectureType === 'yangon_pit') {
      // Lethwei Pit: Flaming torches, wooden palisades
      ctx.fillStyle = '#292524';
      for (let x = -100; x < arenaW + 100; x += 120) {
        ctx.fillRect(x, 140, 16, groundY - 140);
      }
      // Torches with animated flicker
      const t = Date.now() * 0.005;
      [150, 450, 750, 1050].forEach((tx) => {
        ctx.fillStyle = '#78350f';
        ctx.fillRect(tx, 160, 12, groundY - 160);
        // Flame glow
        const rad = 25 + Math.sin(t + tx) * 5;
        const flameGrad = ctx.createRadialGradient(tx + 6, 150, 2, tx + 6, 150, rad);
        flameGrad.addColorStop(0, '#fef08a');
        flameGrad.addColorStop(0.5, '#f97316');
        flameGrad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = flameGrad;
        ctx.beginPath();
        ctx.arc(tx + 6, 150, rad, 0, Math.PI * 2);
        ctx.fill();
      });
    } else if (stage.bgArchitectureType === 'china_mountain') {
      // Ancient Stone Terrace & Dragons
      ctx.fillStyle = '#1e293b';
      // Distant mountain peaks
      ctx.beginPath();
      ctx.moveTo(-200, groundY);
      ctx.lineTo(200, 120);
      ctx.lineTo(600, groundY - 80);
      ctx.lineTo(950, 90);
      ctx.lineTo(arenaW + 200, groundY);
      ctx.fill();
      // Temple Pillars
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(180, 80, 40, groundY - 80);
      ctx.fillRect(arenaW - 220, 80, 40, groundY - 80);
    } else {
      // Grand Arena / Underground Cage
      ctx.fillStyle = 'rgba(255, 255, 255, 0.04)';
      ctx.font = 'bold 120px "Bebas Neue", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('WORLD MARTIAL LEGENDS', arenaW / 2, groundY - 160);
    }

    // Floor / Mat rendering
    const floorGrad = ctx.createLinearGradient(0, groundY, 0, groundY + 140);
    floorGrad.addColorStop(0, stage.floorColor);
    floorGrad.addColorStop(1, '#09090b');
    ctx.fillStyle = floorGrad;
    ctx.fillRect(-200, groundY, arenaW + 400, 140);

    // Floor edge highlight line
    ctx.strokeStyle = stage.lineColor;
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(-200, groundY);
    ctx.lineTo(arenaW + 400, groundY);
    ctx.stroke();

    // Perspective lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.lineWidth = 2;
    for (let x = 0; x <= arenaW; x += 150) {
      ctx.beginPath();
      ctx.moveTo(x, groundY);
      ctx.lineTo(x + (x - arenaW / 2) * 0.4, groundY + 140);
      ctx.stroke();
    }
  }

  private renderShadow(f: FighterEntity) {
    const ctx = this.ctx;
    const groundY = 510;
    const airOffset = Math.max(0, groundY - f.y);
    const scale = Math.max(0.3, 1 - airOffset / 400);

    ctx.save();
    ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
    ctx.beginPath();
    ctx.ellipse(f.x, groundY, 40 * scale, 12 * scale, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // ===================== FIGHTER SKELETAL RENDERING =====================

  private renderFighter(f: FighterEntity, engine: FightEngine) {
    const ctx = this.ctx;
    ctx.save();
    ctx.translate(f.x, f.y);
    ctx.scale(f.facing, 1);

    const v = f.data.visuals;
    const t = Date.now() * 0.008;

    // Calculate pose offsets based on ActionState and StateFrame
    let headX = 0, headY = -120;
    let chestX = 0, chestY = -85;
    let hipX = 0, hipY = -55;
    let leadHandX = 25, leadHandY = -90;
    let rearHandX = -15, rearHandY = -85;
    let leadFootX = 20, leadFootY = 0;
    let rearFootX = -20, rearFootY = 0;

    // Idle stance bobbing & discipline pose adjustments
    if (f.state === 'IDLE') {
      const bob = Math.sin(t) * 3;
      chestY += bob;
      headY += bob;
      if (v.stanceStyle === 'muay_thai') {
        // High hands, rhythmic bouncing knee check
        leadHandY = -110;
        rearHandY = -105;
        leadHandX = 22;
        leadFootY = Math.abs(Math.sin(t * 1.5)) * -14;
      } else if (v.stanceStyle === 'lethwei') {
        // Low forward stalking guard
        chestX = 12;
        headX = 14;
        leadHandY = -95;
        rearHandY = -90;
      } else if (v.stanceStyle === 'sanda') {
        // Sideways mobile stance
        leadFootX = 30;
        rearFootX = -25;
        leadHandY = -100;
      } else if (v.stanceStyle === 'yaw_yan') {
        // Low coiled feline stance
        hipY = -48;
        chestY = -78 + bob;
        headY = -110 + bob;
        leadHandX = 30;
        leadHandY = -85;
      }
    } else if (f.state === 'WALK_FORWARD') {
      const walk = Math.sin(t * 2);
      leadFootX = 25 + walk * 15;
      rearFootX = -25 - walk * 15;
      chestX = 6;
      headX = 8;
    } else if (f.state === 'WALK_BACKWARD') {
      const walk = Math.sin(t * 2);
      leadFootX = 20 - walk * 12;
      rearFootX = -25 + walk * 12;
      chestX = -6;
    } else if (f.state === 'CROUCH') {
      hipY = -35;
      chestY = -58;
      headY = -82;
      leadHandY = -65;
      rearHandY = -60;
    } else if (f.state === 'JUMPING') {
      hipY = -45;
      chestY = -75;
      headY = -105;
      leadFootX = 15;
      leadFootY = -25;
      rearFootX = -15;
      rearFootY = -18;
    } else if (f.state === 'LIGHT_PUNCH') {
      const prog = f.stateFrame / f.totalStateFrames;
      const reach = Math.sin(prog * Math.PI) * 45;
      leadHandX = 25 + reach;
      leadHandY = -100;
      chestX = reach * 0.2;
    } else if (f.state === 'HEAVY_PUNCH') {
      const prog = f.stateFrame / f.totalStateFrames;
      const reach = Math.sin(prog * Math.PI) * 65;
      rearHandX = -10 + reach;
      rearHandY = -95;
      chestX = reach * 0.3;
      leadHandX = -5;
    } else if (f.state === 'LIGHT_KICK') {
      const prog = f.stateFrame / f.totalStateFrames;
      const reach = Math.sin(prog * Math.PI) * 55;
      leadFootX = 20 + reach;
      leadFootY = -60 * Math.sin(prog * Math.PI);
    } else if (f.state === 'HEAVY_KICK') {
      const prog = f.stateFrame / f.totalStateFrames;
      const arc = Math.sin(prog * Math.PI);
      rearFootX = -10 + arc * 75;
      rearFootY = -120 * arc;
      chestX = -arc * 15;
      this.drawKickTrail(ctx, rearFootX, rearFootY, v.trailColor);
    } else if (f.state === 'SPECIAL_1') {
      const prog = f.stateFrame / f.totalStateFrames;
      const lunge = Math.sin(prog * Math.PI) * 80;
      leadHandX = 30 + lunge;
      leadHandY = -95;
      leadFootX = 35 + lunge * 0.5;
      this.drawAura(ctx, 0, chestY, v.trailColor, 40);
    } else if (f.state === 'SPECIAL_2') {
      const prog = f.stateFrame / f.totalStateFrames;
      const arc = Math.sin(prog * Math.PI);
      rearFootX = -10 + arc * 85;
      rearFootY = -80 * arc;
      this.drawKickTrail(ctx, rearFootX, rearFootY, v.trailColor);
      this.drawAura(ctx, rearFootX, rearFootY, v.trailColor, 35);
    } else if (f.state === 'ULTIMATE') {
      const prog = f.stateFrame / f.totalStateFrames;
      const blast = Math.sin(prog * Math.PI) * 95;
      leadHandX = 40 + blast;
      leadHandY = -95;
      leadFootX = 45;
      this.drawAura(ctx, 0, chestY, '#f59e0b', 65);
    } else if (f.state === 'BLOCK_HIGH') {
      leadHandX = 18;
      leadHandY = -115;
      rearHandX = 12;
      rearHandY = -105;
      chestX = -10;
    } else if (f.state === 'BLOCK_LOW') {
      hipY = -35;
      chestY = -58;
      headY = -82;
      leadHandX = 20;
      leadHandY = -55;
      rearHandX = 14;
      rearHandY = -48;
    } else if (f.state === 'HIT_STUN') {
      chestX = -20;
      headX = -26;
      headY = -110;
      leadHandX = -5;
      rearHandX = -25;
    } else if (f.state === 'KNOCKDOWN') {
      hipY = -15;
      chestY = -15;
      headY = -15;
      chestX = -45;
      headX = -75;
      leadFootX = 20;
      leadFootY = -10;
    } else if (f.state === 'GET_UP') {
      const prog = f.stateFrame / f.totalStateFrames;
      hipY = -15 - prog * 40;
      chestY = -15 - prog * 70;
      headY = -15 - prog * 105;
    } else if (f.state === 'VICTORY') {
      leadHandX = 10;
      leadHandY = -140; // Raising arm in victory
      rearHandX = -15;
      rearHandY = -50;
    }

    // Draw Limb Segments
    ctx.lineWidth = v.build === 'heavy' ? 14 : v.build === 'muscular' ? 12 : 10;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    // 1. Rear Leg
    ctx.strokeStyle = v.skinTone;
    ctx.beginPath();
    ctx.moveTo(hipX - 10, hipY);
    ctx.lineTo(rearFootX, rearFootY);
    ctx.stroke();

    // 2. Rear Arm
    ctx.beginPath();
    ctx.moveTo(chestX - 8, chestY - 10);
    ctx.lineTo(rearHandX, rearHandY);
    ctx.stroke();

    // 3. Torso & Attire
    ctx.strokeStyle = v.primaryColor;
    ctx.lineWidth = v.build === 'heavy' ? 34 : v.build === 'muscular' ? 28 : 24;
    ctx.beginPath();
    ctx.moveTo(hipX, hipY);
    ctx.lineTo(chestX, chestY);
    ctx.stroke();

    // Attire Specifics (Gi, Trunks, Wraps)
    if (v.attire === 'karate_gi') {
      // Black belt tie
      ctx.strokeStyle = v.secondaryColor;
      ctx.lineWidth = 8;
      ctx.beginPath();
      ctx.moveTo(hipX - 14, hipY);
      ctx.lineTo(hipX + 14, hipY);
      ctx.stroke();
      // Flowing belt ends
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(hipX + 5, hipY);
      ctx.lineTo(hipX + 12, hipY + 22);
      ctx.stroke();
    } else if (v.attire === 'muay_thai') {
      // Thai shorts waistband
      ctx.strokeStyle = v.secondaryColor;
      ctx.lineWidth = 6;
      ctx.beginPath();
      ctx.moveTo(hipX - 14, hipY);
      ctx.lineTo(hipX + 14, hipY);
      ctx.stroke();
      // Prajioud arm bands
      ctx.strokeStyle = v.accentColor;
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.arc(leadHandX - 10, leadHandY + 15, 6, 0, Math.PI * 2);
      ctx.stroke();
    } else if (v.attire === 'lethwei_wraps') {
      // Tape wraps on hands
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(leadHandX, leadHandY, 8, 0, Math.PI * 2);
      ctx.arc(rearHandX, rearHandY, 8, 0, Math.PI * 2);
      ctx.fill();
    } else if (v.attire === 'yaw_yan_trunks') {
      // Yaw Yan Red trunks & Yellow waist cord
      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(hipX - 14, hipY);
      ctx.lineTo(hipX + 14, hipY);
      ctx.stroke();
    }

    // 4. Lead Leg
    ctx.strokeStyle = v.skinTone;
    ctx.lineWidth = v.build === 'heavy' ? 14 : v.build === 'muscular' ? 12 : 10;
    ctx.beginPath();
    ctx.moveTo(hipX + 8, hipY);
    ctx.lineTo(leadFootX, leadFootY);
    ctx.stroke();

    // 5. Lead Arm
    ctx.beginPath();
    ctx.moveTo(chestX + 10, chestY - 10);
    ctx.lineTo(leadHandX, leadHandY);
    ctx.stroke();

    // 6. Head & Facial Features
    ctx.fillStyle = v.skinTone;
    ctx.beginPath();
    ctx.arc(headX, headY, 15, 0, Math.PI * 2);
    ctx.fill();

    // Hair / Headband
    ctx.fillStyle = v.hairColor;
    if (v.hairStyle === 'topknot') {
      ctx.beginPath();
      ctx.arc(headX, headY - 14, 8, 0, Math.PI * 2);
      ctx.fill();
    } else if (v.hairStyle === 'spiky') {
      ctx.beginPath();
      ctx.moveTo(headX - 14, headY - 8);
      ctx.lineTo(headX - 18, headY - 22);
      ctx.lineTo(headX - 4, headY - 18);
      ctx.lineTo(headX + 8, headY - 24);
      ctx.lineTo(headX + 16, headY - 8);
      ctx.fill();
    } else if (v.hairStyle === 'headband') {
      ctx.strokeStyle = v.accentColor;
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.arc(headX, headY - 4, 16, Math.PI * 0.8, Math.PI * 2.2);
      ctx.stroke();
    }

    // Focused Eyes
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(headX + 5, headY - 3, 5, 3);
    ctx.fillStyle = '#09090b';
    ctx.fillRect(headX + 7, headY - 3, 3, 3);

    ctx.restore();
  }

  private drawKickTrail(ctx: CanvasRenderingContext2D, x: number, y: number, color: string) {
    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = 8;
    ctx.globalAlpha = 0.6;
    ctx.beginPath();
    ctx.arc(0, 0, Math.sqrt(x * x + y * y), -Math.PI * 0.25, 0.1);
    ctx.stroke();
    ctx.restore();
  }

  private drawAura(ctx: CanvasRenderingContext2D, x: number, y: number, color: string, radius: number) {
    ctx.save();
    const grad = ctx.createRadialGradient(x, y, 2, x, y, radius);
    grad.addColorStop(0, color);
    grad.addColorStop(0.7, 'rgba(255, 255, 255, 0.4)');
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // ===================== PARTICLES RENDERING =====================

  private renderParticles(particles: ParticleEffect[]) {
    const ctx = this.ctx;
    particles.forEach((p) => {
      const alpha = 1 - p.life / p.maxLife;
      ctx.save();
      ctx.globalAlpha = alpha;

      if (p.type === 'spark') {
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.type === 'ring') {
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.stroke();
      } else if (p.type === 'smoke') {
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    });
  }

  private renderSuperEffect(engine: FightEngine) {
    const ctx = this.ctx;
    ctx.save();
    ctx.fillStyle = `rgba(0, 0, 0, ${engine.state.superFlashAlpha * 0.75})`;
    ctx.fillRect(-200, 0, engine.ARENA_WIDTH + 400, engine.ARENA_HEIGHT);

    // Speed lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
    ctx.lineWidth = 2;
    for (let i = 0; i < 20; i++) {
      const y = Math.random() * engine.ARENA_HEIGHT;
      ctx.beginPath();
      ctx.moveTo(-200, y);
      ctx.lineTo(engine.ARENA_WIDTH + 200, y + (Math.random() - 0.5) * 40);
      ctx.stroke();
    }

    // Ultimate Cut-In Banner
    ctx.fillStyle = '#dc2626';
    ctx.fillRect(-200, 220, engine.ARENA_WIDTH + 400, 70);
    ctx.fillStyle = '#facc15';
    ctx.font = 'italic bold 44px "Bebas Neue", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(engine.state.superFlashText, engine.state.cameraX, 270);
    ctx.restore();
  }

  // ===================== IN-FIGHT HUD & ANNOUNCEMENTS =====================

  private renderHUD(engine: FightEngine) {
    const ctx = this.ctx;
    const w = this.canvas.width;

    const p1 = engine.p1;
    const p2 = engine.p2;

    const barW = Math.min(380, w * 0.38);
    const barH = 24;
    const topY = 28;

    // --- P1 HEALTH BAR ---
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(30, topY, barW, barH);
    // Red damage chunk
    const p1RedW = (p1.redHealth / 100) * (barW - 4);
    ctx.fillStyle = '#ef4444';
    ctx.fillRect(32 + (barW - 4 - p1RedW), topY + 2, p1RedW, barH - 4);
    // Current health
    const p1HealthW = (p1.health / 100) * (barW - 4);
    const p1Grad = ctx.createLinearGradient(0, topY, 0, topY + barH);
    p1Grad.addColorStop(0, '#facc15');
    p1Grad.addColorStop(1, '#eab308');
    ctx.fillStyle = p1Grad;
    ctx.fillRect(32 + (barW - 4 - p1HealthW), topY + 2, p1HealthW, barH - 4);

    // P1 Name & Flag
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 20px "Chakra Petch", sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(`${p1.data.flag} ${p1.data.name.toUpperCase()}`, 32, topY - 8);

    // P1 Super Meter Bar
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(30, topY + barH + 6, barW * 0.75, 12);
    const p1MeterW = (p1.superMeter / 100) * (barW * 0.75 - 4);
    ctx.fillStyle = p1.superMeter >= 100 ? (Date.now() % 200 < 100 ? '#facc15' : '#ef4444') : '#38bdf8';
    ctx.fillRect(32, topY + barH + 8, p1MeterW, 8);
    ctx.fillStyle = '#94a3b8';
    ctx.font = 'bold 10px "Chakra Petch", sans-serif';
    ctx.fillText(p1.superMeter >= 100 ? 'SUPER READY' : `SUPER ${Math.floor(p1.superMeter)}%`, 32, topY + barH + 28);

    // P1 Rounds Won Markers
    for (let r = 0; r < engine.state.maxRounds; r++) {
      ctx.fillStyle = r < p1.roundsWon ? '#eab308' : '#334155';
      ctx.beginPath();
      ctx.arc(35 + r * 22, topY + barH + 38, 7, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }

    // --- P2 HEALTH BAR ---
    const p2X = w - 30 - barW;
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(p2X, topY, barW, barH);
    // Red damage chunk
    const p2RedW = (p2.redHealth / 100) * (barW - 4);
    ctx.fillStyle = '#ef4444';
    ctx.fillRect(p2X + 2, topY + 2, p2RedW, barH - 4);
    // Current health
    const p2HealthW = (p2.health / 100) * (barW - 4);
    const p2Grad = ctx.createLinearGradient(0, topY, 0, topY + barH);
    p2Grad.addColorStop(0, '#facc15');
    p2Grad.addColorStop(1, '#eab308');
    ctx.fillStyle = p2Grad;
    ctx.fillRect(p2X + 2, topY + 2, p2HealthW, barH - 4);

    // P2 Name & Flag
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 20px "Chakra Petch", sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText(`${p2.data.name.toUpperCase()} ${p2.data.flag}`, w - 32, topY - 8);

    // P2 Super Meter Bar
    const p2MeterWTotal = barW * 0.75;
    const p2MeterX = w - 30 - p2MeterWTotal;
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(p2MeterX, topY + barH + 6, p2MeterWTotal, 12);
    const p2MeterW = (p2.superMeter / 100) * (p2MeterWTotal - 4);
    ctx.fillStyle = p2.superMeter >= 100 ? (Date.now() % 200 < 100 ? '#facc15' : '#ef4444') : '#38bdf8';
    ctx.fillRect(w - 32 - p2MeterW, topY + barH + 8, p2MeterW, 8);
    ctx.fillStyle = '#94a3b8';
    ctx.font = 'bold 10px "Chakra Petch", sans-serif';
    ctx.fillText(p2.superMeter >= 100 ? 'SUPER READY' : `SUPER ${Math.floor(p2.superMeter)}%`, w - 32, topY + barH + 28);

    // P2 Rounds Won Markers
    for (let r = 0; r < engine.state.maxRounds; r++) {
      ctx.fillStyle = r < p2.roundsWon ? '#eab308' : '#334155';
      ctx.beginPath();
      ctx.arc(w - 35 - r * 22, topY + barH + 38, 7, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }

    // --- MATCH TIMER ---
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 44px "Bebas Neue", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillStyle = engine.state.roundTimer <= 10 ? '#ef4444' : '#facc15';
    ctx.fillText(engine.mode === 'TRAINING' ? '∞' : String(engine.state.roundTimer), w / 2, topY + 28);

    // Stage Name Badge (Subtle top center)
    ctx.font = '11px "Chakra Petch", sans-serif';
    ctx.fillStyle = '#94a3b8';
    ctx.fillText(`${engine.state.currentStage.name.toUpperCase()} · ${engine.state.currentStage.country}`, w / 2, topY + 46);

    // --- COMBO COUNTERS ---
    if (p1.comboHits >= 2) {
      ctx.fillStyle = '#ef4444';
      ctx.font = 'italic bold 36px "Bebas Neue", sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(`${p1.comboHits} HITS!`, 40, 160);
      ctx.font = 'bold 16px "Chakra Petch", sans-serif';
      ctx.fillStyle = '#facc15';
      ctx.fillText(`${p1.comboDamage} DAMAGE`, 40, 185);
    }
    if (p2.comboHits >= 2) {
      ctx.fillStyle = '#ef4444';
      ctx.font = 'italic bold 36px "Bebas Neue", sans-serif';
      ctx.textAlign = 'right';
      ctx.fillText(`${p2.comboHits} HITS!`, w - 40, 160);
      ctx.font = 'bold 16px "Chakra Petch", sans-serif';
      ctx.fillStyle = '#facc15';
      ctx.fillText(`${p2.comboDamage} DAMAGE`, w - 40, 185);
    }

    // --- COUNTER HIT INDICATOR ---
    if (engine.state.counterHitTextTime > 0) {
      ctx.save();
      ctx.fillStyle = '#f97316';
      ctx.font = 'italic bold 28px "Bebas Neue", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('⚡ COUNTER HIT! ⚡', w / 2, 140);
      ctx.restore();
    }

    // --- MATCH ANNOUNCEMENT OVERLAYS (ROUND 1, FIGHT, K.O., VICTORY) ---
    if (engine.state.announcementText) {
      ctx.save();
      ctx.textAlign = 'center';

      // Big text
      ctx.font = 'italic bold 72px "Bebas Neue", sans-serif';
      ctx.fillStyle = '#09090b';
      ctx.fillText(engine.state.announcementText, w / 2 + 4, 284);
      ctx.fillStyle = '#facc15';
      ctx.fillText(engine.state.announcementText, w / 2, 280);

      // Subtext
      if (engine.state.announcementSubtext) {
        ctx.font = 'bold 22px "Chakra Petch", sans-serif';
        ctx.fillStyle = '#ffffff';
        ctx.fillText(engine.state.announcementSubtext, w / 2, 320);
      }
      ctx.restore();
    }
  }
}
