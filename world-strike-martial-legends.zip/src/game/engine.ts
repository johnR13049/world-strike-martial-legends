import { FighterActionState, FighterData, Hitbox, Hurtbox, ParticleEffect, StageData } from '../types/fighter';
import { sound } from '../audio/soundEngine';

export interface FighterEntity {
  id: string;
  data: FighterData;
  isPlayer: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  facing: 1 | -1; // 1 = right, -1 = left
  isGrounded: boolean;
  health: number;
  redHealth: number;
  maxHealth: number;
  superMeter: number;
  maxSuperMeter: number;
  guardMeter: number;
  maxGuardMeter: number;
  state: FighterActionState;
  stateFrame: number;
  totalStateFrames: number;
  hasHitInState: boolean;
  comboHits: number;
  comboDamage: number;
  roundsWon: number;
  invincibleFrames: number;
  isCrouching: boolean;
  activeHitbox: Hitbox | null;
  hurtbox: Hurtbox;
  customColor: string;
}

export interface FightGameState {
  matchState: 'INTRO' | 'ROUND_ANNOUNCING' | 'FIGHTING' | 'ROUND_END' | 'MATCH_OVER' | 'PAUSED';
  roundNumber: number;
  maxRounds: number;
  roundTimer: number;
  announcementText: string;
  announcementSubtext: string;
  announcementAlpha: number;
  winner: 1 | 2 | null;
  isPerfect: boolean;
  cameraX: number;
  cameraZoom: number;
  shakeTime: number;
  shakeIntensity: number;
  hitStopTime: number;
  particles: ParticleEffect[];
  isCounterHit: boolean;
  counterHitTextTime: number;
  superFlashAlpha: number;
  superFlashText: string;
  currentStage: StageData;
}

export class FightEngine {
  public p1: FighterEntity;
  public p2: FighterEntity;
  public state: FightGameState;
  public mode: 'ARCADE' | 'VERSUS' | 'TRAINING';
  public difficulty: 'EASY' | 'MEDIUM' | 'HARD' | 'MASTER' = 'MEDIUM';
  public isP2Human: boolean = false;

  // Ground and Arena Bounds
  public readonly ARENA_WIDTH = 1300;
  public readonly ARENA_HEIGHT = 650;
  public readonly GROUND_Y = 510;

  // Input states
  public p1Inputs = {
    left: false,
    right: false,
    up: false,
    down: false,
    lightPunch: false,
    heavyPunch: false,
    lightKick: false,
    heavyKick: false,
    special1: false,
    special2: false,
    ultimate: false,
    guard: false,
  };

  public p2Inputs = {
    left: false,
    right: false,
    up: false,
    down: false,
    lightPunch: false,
    heavyPunch: false,
    lightKick: false,
    heavyKick: false,
    special1: false,
    special2: false,
    ultimate: false,
    guard: false,
  };

  // AI timing memory
  private aiActionCooldown = 0;
  private aiStrategyTimer = 0;
  private aiDesiredDistance = 140;

  constructor(
    p1Data: FighterData,
    p2Data: FighterData,
    stage: StageData,
    mode: 'ARCADE' | 'VERSUS' | 'TRAINING' = 'VERSUS',
    isP2Human = false,
    difficulty: 'EASY' | 'MEDIUM' | 'HARD' | 'MASTER' = 'MEDIUM'
  ) {
    this.mode = mode;
    this.isP2Human = isP2Human;
    this.difficulty = difficulty;

    this.p1 = this.createFighter(p1Data, 420, true, 1);
    this.p2 = this.createFighter(p2Data, 780, isP2Human, -1);

    this.state = {
      matchState: 'INTRO',
      roundNumber: 1,
      maxRounds: mode === 'TRAINING' ? 1 : 2, // 2 rounds to win
      roundTimer: 99,
      announcementText: 'GET READY',
      announcementSubtext: `${p1Data.name} VS ${p2Data.name}`,
      announcementAlpha: 1,
      winner: null,
      isPerfect: false,
      cameraX: 600,
      cameraZoom: 1,
      shakeTime: 0,
      shakeIntensity: 0,
      hitStopTime: 0,
      particles: [],
      isCounterHit: false,
      counterHitTextTime: 0,
      superFlashAlpha: 0,
      superFlashText: '',
      currentStage: stage,
    };

    sound.startStageBgm(stage.id);
  }

  private createFighter(
    data: FighterData,
    startX: number,
    isPlayer: boolean,
    facing: 1 | -1
  ): FighterEntity {
    return {
      id: data.id,
      data,
      isPlayer,
      x: startX,
      y: this.GROUND_Y,
      vx: 0,
      vy: 0,
      facing,
      isGrounded: true,
      health: 100,
      redHealth: 100,
      maxHealth: 100,
      superMeter: this.mode === 'TRAINING' ? 100 : 0,
      maxSuperMeter: 100,
      guardMeter: 100,
      maxGuardMeter: 100,
      state: 'IDLE',
      stateFrame: 0,
      totalStateFrames: 24,
      hasHitInState: false,
      comboHits: 0,
      comboDamage: 0,
      roundsWon: 0,
      invincibleFrames: 0,
      isCrouching: false,
      activeHitbox: null,
      hurtbox: { x: startX - 35, y: this.GROUND_Y - 140, width: 70, height: 140 },
      customColor: data.visuals.primaryColor,
    };
  }

  public update(deltaTime: number) {
    if (this.state.matchState === 'PAUSED') return;

    // Handle Hit Stop
    if (this.state.hitStopTime > 0) {
      this.state.hitStopTime--;
      this.updateParticles();
      return;
    }

    // Handle Screen Shake decay
    if (this.state.shakeTime > 0) {
      this.state.shakeTime--;
    } else {
      this.state.shakeIntensity = 0;
    }

    // Super flash alpha decay
    if (this.state.superFlashAlpha > 0) {
      this.state.superFlashAlpha -= 0.04;
    }

    // Counter hit indicator timer
    if (this.state.counterHitTextTime > 0) {
      this.state.counterHitTextTime--;
    }

    // Match State Logic
    switch (this.state.matchState) {
      case 'INTRO':
        this.updateIntro();
        break;
      case 'ROUND_ANNOUNCING':
        this.updateRoundAnnouncing();
        break;
      case 'FIGHTING':
        this.updateFighting(deltaTime);
        break;
      case 'ROUND_END':
        this.updateRoundEnd();
        break;
      case 'MATCH_OVER':
        this.updateMatchOver();
        break;
    }

    // Update Particles
    this.updateParticles();

    // Smooth Camera Tracking
    const midX = (this.p1.x + this.p2.x) / 2;
    this.state.cameraX += (midX - this.state.cameraX) * 0.1;
    const dist = Math.abs(this.p1.x - this.p2.x);
    const targetZoom = Math.max(0.85, Math.min(1.15, 1200 / (dist + 600)));
    this.state.cameraZoom += (targetZoom - this.state.cameraZoom) * 0.05;
  }

  private introTimer = 0;
  private updateIntro() {
    this.introTimer++;
    if (this.introTimer === 1) {
      sound.announce(`Round ${this.state.roundNumber}`);
    }
    if (this.introTimer > 90) {
      this.introTimer = 0;
      this.state.matchState = 'ROUND_ANNOUNCING';
      this.state.announcementText = `ROUND ${this.state.roundNumber}`;
      this.state.announcementSubtext = 'READY...';
      this.state.announcementAlpha = 1;
    }
  }

  private announceTimer = 0;
  private updateRoundAnnouncing() {
    this.announceTimer++;
    if (this.announceTimer === 30) {
      sound.announce('FIGHT');
      this.state.announcementText = 'FIGHT!';
      this.state.announcementSubtext = '';
      sound.playRoundBell();
    }
    if (this.announceTimer > 60) {
      this.announceTimer = 0;
      this.state.matchState = 'FIGHTING';
      this.state.announcementText = '';
    }
  }

  private matchOverTimer = 0;
  private updateRoundEnd() {
    this.matchOverTimer++;
    this.updateFighterPhysics(this.p1);
    this.updateFighterPhysics(this.p2);

    if (this.matchOverTimer > 150) {
      this.matchOverTimer = 0;
      // Check if match won
      if (this.p1.roundsWon >= this.state.maxRounds || this.p2.roundsWon >= this.state.maxRounds) {
        this.state.matchState = 'MATCH_OVER';
        const winnerFighter = this.p1.roundsWon >= this.state.maxRounds ? this.p1 : this.p2;
        sound.announce(`Winner is ${winnerFighter.data.name}`);
        this.state.announcementText = 'VICTORY!';
        this.state.announcementSubtext = `${winnerFighter.data.name} WINS!`;
      } else {
        // Next round
        this.state.roundNumber++;
        this.resetRound();
        this.state.matchState = 'ROUND_ANNOUNCING';
        this.state.announcementText = `ROUND ${this.state.roundNumber}`;
        this.state.announcementSubtext = 'READY...';
        sound.announce(`Round ${this.state.roundNumber}`);
      }
    }
  }

  private updateMatchOver() {
    this.updateFighterPhysics(this.p1);
    this.updateFighterPhysics(this.p2);
  }

  private timerSubFrame = 0;
  private updateFighting(deltaTime: number) {
    // Round Timer (unless Training mode)
    if (this.mode !== 'TRAINING') {
      this.timerSubFrame++;
      if (this.timerSubFrame >= 60) {
        this.timerSubFrame = 0;
        if (this.state.roundTimer > 0) {
          this.state.roundTimer--;
        } else {
          // Time over
          this.handleTimeOver();
          return;
        }
      }
    }

    // AI logic for CPU
    if (!this.isP2Human) {
      this.updateAI();
    }

    // Update Inputs for P1 & P2
    this.processFighterInput(this.p1, this.p1Inputs, this.p2);
    this.processFighterInput(this.p2, this.p2Inputs, this.p1);

    // Update Physics & Animation states
    this.updateFighterPhysics(this.p1);
    this.updateFighterPhysics(this.p2);

    // Dynamic Facing direction
    if (this.p1.isGrounded && this.p1.state === 'IDLE') {
      this.p1.facing = this.p1.x < this.p2.x ? 1 : -1;
    }
    if (this.p2.isGrounded && this.p2.state === 'IDLE') {
      this.p2.facing = this.p2.x < this.p1.x ? 1 : -1;
    }

    // Attack Collision Detection
    this.checkCollisions(this.p1, this.p2);
    this.checkCollisions(this.p2, this.p1);

    // Push apart when overlapping
    const dist = Math.abs(this.p1.x - this.p2.x);
    const minDist = 65;
    if (dist < minDist && this.p1.isGrounded && this.p2.isGrounded) {
      const overlap = (minDist - dist) / 2;
      if (this.p1.x < this.p2.x) {
        this.p1.x = Math.max(80, this.p1.x - overlap);
        this.p2.x = Math.min(this.ARENA_WIDTH - 80, this.p2.x + overlap);
      } else {
        this.p1.x = Math.min(this.ARENA_WIDTH - 80, this.p1.x + overlap);
        this.p2.x = Math.max(80, this.p2.x - overlap);
      }
    }

    // Red health slow recovery drain effect
    if (this.p1.redHealth > this.p1.health) {
      this.p1.redHealth -= 0.3;
    }
    if (this.p2.redHealth > this.p2.health) {
      this.p2.redHealth -= 0.3;
    }

    // Check KO
    if (this.p1.health <= 0 || this.p2.health <= 0) {
      this.handleRoundFinish();
    }
  }

  private handleTimeOver() {
    sound.announce('Time Over');
    this.state.matchState = 'ROUND_END';
    this.state.announcementText = 'TIME OVER!';
    if (this.p1.health > this.p2.health) {
      this.p1.roundsWon++;
      this.p1.state = 'VICTORY';
      this.p2.state = 'DEFEAT';
      this.state.announcementSubtext = `${this.p1.data.name} WINS!`;
    } else if (this.p2.health > this.p1.health) {
      this.p2.roundsWon++;
      this.p2.state = 'VICTORY';
      this.p1.state = 'DEFEAT';
      this.state.announcementSubtext = `${this.p2.data.name} WINS!`;
    } else {
      this.state.announcementSubtext = 'DRAW GAME';
    }
  }

  private handleRoundFinish() {
    this.state.matchState = 'ROUND_END';
    sound.announce('Knockout');
    this.state.announcementText = 'K.O.!';
    this.state.shakeTime = 30;
    this.state.shakeIntensity = 16;
    this.state.hitStopTime = 15;

    if (this.p1.health <= 0) {
      this.p2.roundsWon++;
      this.p1.state = 'DEFEAT';
      this.p2.state = 'VICTORY';
      this.state.announcementSubtext = `${this.p2.data.name} WINS!`;
    } else {
      this.p1.roundsWon++;
      this.p2.state = 'DEFEAT';
      this.p1.state = 'VICTORY';
      this.state.announcementSubtext = `${this.p1.data.name} WINS!`;
      if (this.p1.health >= 100) {
        this.state.isPerfect = true;
        setTimeout(() => sound.announce('Perfect'), 600);
      }
    }
  }

  private resetRound() {
    this.state.roundTimer = 99;
    this.timerSubFrame = 0;
    this.p1.x = 420;
    this.p1.y = this.GROUND_Y;
    this.p1.vx = 0;
    this.p1.vy = 0;
    this.p1.health = 100;
    this.p1.redHealth = 100;
    this.p1.state = 'IDLE';
    this.p1.stateFrame = 0;
    this.p1.facing = 1;
    this.p1.activeHitbox = null;
    this.p1.comboHits = 0;
    this.p1.comboDamage = 0;

    this.p2.x = 780;
    this.p2.y = this.GROUND_Y;
    this.p2.vx = 0;
    this.p2.vy = 0;
    this.p2.health = 100;
    this.p2.redHealth = 100;
    this.p2.state = 'IDLE';
    this.p2.stateFrame = 0;
    this.p2.facing = -1;
    this.p2.activeHitbox = null;
    this.p2.comboHits = 0;
    this.p2.comboDamage = 0;
  }

  // ===================== INPUT HANDLING & COMBAT SYSTEM =====================

  private processFighterInput(f: FighterEntity, inp: typeof this.p1Inputs, opp: FighterEntity) {
    if (f.health <= 0 || f.state === 'DEFEAT' || f.state === 'VICTORY') return;

    // Hit stun / Knockdown locks out input
    if (f.state === 'HIT_STUN' || f.state === 'KNOCKDOWN' || f.state === 'GET_UP') {
      return;
    }

    const canCancel =
      f.state === 'LIGHT_PUNCH' ||
      f.state === 'LIGHT_KICK' ||
      f.state === 'HEAVY_PUNCH' ||
      f.state === 'HEAVY_KICK';

    // 1. Ultimate Attack Check (Costs 100 Super Meter)
    if (inp.ultimate && f.superMeter >= 100 && (f.state === 'IDLE' || f.state === 'CROUCH' || canCancel)) {
      f.superMeter = 0;
      this.executeAttack(f, 'ULTIMATE', 60, f.data.moves.ultimate.damage, f.data.moves.ultimate.hitType, true);
      this.state.superFlashAlpha = 1;
      this.state.superFlashText = f.data.moves.ultimate.name.toUpperCase();
      this.state.hitStopTime = 12;
      this.state.shakeTime = 16;
      this.state.shakeIntensity = 8;
      sound.playSuperFlash();
      sound.announce(f.data.moves.ultimate.name);
      return;
    }

    // 2. Special Moves
    if (inp.special1 && (f.state === 'IDLE' || f.state === 'CROUCH' || canCancel)) {
      this.executeAttack(
        f,
        'SPECIAL_1',
        34,
        f.data.moves.special1.damage,
        f.data.moves.special1.hitType,
        !!f.data.moves.special1.isKnockdown
      );
      sound.playWhoosh();
      return;
    }

    if (inp.special2 && (f.state === 'IDLE' || f.state === 'CROUCH' || canCancel)) {
      this.executeAttack(
        f,
        'SPECIAL_2',
        38,
        f.data.moves.special2.damage,
        f.data.moves.special2.hitType,
        !!f.data.moves.special2.isKnockdown
      );
      sound.playWhoosh();
      return;
    }

    // 3. Normal Attacks
    if (f.isGrounded && (f.state === 'IDLE' || f.state === 'WALK_FORWARD' || f.state === 'WALK_BACKWARD' || f.state === 'CROUCH')) {
      if (inp.heavyPunch) {
        this.executeAttack(f, 'HEAVY_PUNCH', 26, 12, 'MID', false);
        sound.playWhoosh();
        return;
      }
      if (inp.heavyKick) {
        this.executeAttack(f, 'HEAVY_KICK', 28, 14, inp.down ? 'LOW' : 'HIGH', inp.down);
        sound.playWhoosh();
        return;
      }
      if (inp.lightPunch) {
        this.executeAttack(f, 'LIGHT_PUNCH', 16, 7, 'HIGH', false);
        sound.playWhoosh();
        return;
      }
      if (inp.lightKick) {
        this.executeAttack(f, 'LIGHT_KICK', 18, 8, inp.down ? 'LOW' : 'MID', false);
        sound.playWhoosh();
        return;
      }
    }

    // 4. Movement & Guard
    if (f.isGrounded && (f.state === 'IDLE' || f.state === 'WALK_FORWARD' || f.state === 'WALK_BACKWARD' || f.state === 'CROUCH' || f.state.startsWith('BLOCK'))) {
      const isHoldingBack = (f.facing === 1 && inp.left) || (f.facing === -1 && inp.right);
      const isHoldingFwd = (f.facing === 1 && inp.right) || (f.facing === -1 && inp.left);

      // Guard check
      if (inp.guard || isHoldingBack) {
        if (inp.down) {
          f.state = 'BLOCK_LOW';
          f.isCrouching = true;
        } else {
          f.state = 'BLOCK_HIGH';
          f.isCrouching = false;
        }
        f.vx = 0;
        return;
      }

      // Crouch
      if (inp.down) {
        f.state = 'CROUCH';
        f.isCrouching = true;
        f.vx = 0;
        return;
      }
      f.isCrouching = false;

      // Jump
      if (inp.up && f.isGrounded) {
        f.state = 'JUMPING';
        f.isGrounded = false;
        f.vy = -18;
        if (isHoldingFwd) f.vx = f.facing * 5.5;
        else if (isHoldingBack) f.vx = -f.facing * 4.5;
        else f.vx = 0;
        sound.playWhoosh();
        return;
      }

      // Walk forward / backward
      const moveSpeed = 3.6 * (f.data.attributes.speed / 7.5);
      if (isHoldingFwd) {
        f.state = 'WALK_FORWARD';
        f.vx = f.facing * moveSpeed;
      } else if (isHoldingBack) {
        f.state = 'WALK_BACKWARD';
        f.vx = -f.facing * (moveSpeed * 0.75);
      } else {
        f.state = 'IDLE';
        f.vx = 0;
      }
    }
  }

  private executeAttack(
    f: FighterEntity,
    attackState: FighterActionState,
    totalFrames: number,
    damage: number,
    hitType: 'HIGH' | 'MID' | 'LOW' | 'THROW',
    isKnockdown: boolean
  ) {
    f.state = attackState;
    f.stateFrame = 0;
    f.totalStateFrames = totalFrames;
    f.hasHitInState = false;
    f.vx = f.isGrounded ? f.facing * 1.5 : f.vx;

    // Attributes scaling
    const finalDamage = Math.round(damage * (f.data.attributes.power / 8));

    // Active hitbox parameters based on move
    let reach = 80;
    let hitYOffset = -90;
    let hitHeight = 45;

    if (attackState === 'LIGHT_PUNCH') {
      reach = 65;
      hitYOffset = -120;
    } else if (attackState === 'HEAVY_PUNCH') {
      reach = 85;
      hitYOffset = -100;
    } else if (attackState === 'LIGHT_KICK') {
      reach = 80;
      hitYOffset = hitType === 'LOW' ? -35 : -70;
    } else if (attackState === 'HEAVY_KICK') {
      reach = 100;
      hitYOffset = hitType === 'LOW' ? -30 : -130;
      hitHeight = 55;
    } else if (attackState === 'SPECIAL_1' || attackState === 'SPECIAL_2') {
      reach = 110;
      hitYOffset = -90;
      hitHeight = 60;
    } else if (attackState === 'ULTIMATE') {
      reach = 130;
      hitYOffset = -80;
      hitHeight = 80;
    }

    const hitX = f.facing === 1 ? f.x + 20 : f.x - 20 - reach;

    f.activeHitbox = {
      x: hitX,
      y: f.y + hitYOffset,
      width: reach,
      height: hitHeight,
      damage: finalDamage,
      hitType,
      hitStun: totalFrames / 2 + 10,
      blockStun: 14,
      knockbackX: f.facing * (isKnockdown ? 10 : 5),
      knockbackY: isKnockdown ? -8 : 0,
      isKnockdown,
      canChip: attackState.startsWith('SPECIAL') || attackState === 'ULTIMATE',
    };
  }

  private updateFighterPhysics(f: FighterEntity) {
    // State timer
    f.stateFrame++;

    // Invincible frames countdown
    if (f.invincibleFrames > 0) f.invincibleFrames--;

    // Gravity & Air physics
    if (!f.isGrounded) {
      f.vy += 0.85; // Gravity
      f.x += f.vx;
      f.y += f.vy;

      if (f.y >= this.GROUND_Y) {
        f.y = this.GROUND_Y;
        f.vy = 0;
        f.vx = 0;
        f.isGrounded = true;
        this.addDustPuff(f.x, this.GROUND_Y);
        if (f.state === 'JUMPING') {
          f.state = 'IDLE';
        }
      }
    } else {
      f.x += f.vx;
    }

    // Arena boundary clamp
    f.x = Math.max(90, Math.min(this.ARENA_WIDTH - 90, f.x));

    // Update Hurtbox
    const hHeight = f.isCrouching ? 85 : 140;
    const hY = f.y - hHeight;
    f.hurtbox = {
      x: f.x - 35,
      y: hY,
      width: 70,
      height: hHeight,
      isCrouching: f.isCrouching,
    };

    // State completions
    if (f.stateFrame >= f.totalStateFrames) {
      f.activeHitbox = null;
      if (
        f.state === 'LIGHT_PUNCH' ||
        f.state === 'HEAVY_PUNCH' ||
        f.state === 'LIGHT_KICK' ||
        f.state === 'HEAVY_KICK' ||
        f.state === 'SPECIAL_1' ||
        f.state === 'SPECIAL_2' ||
        f.state === 'ULTIMATE' ||
        f.state === 'HIT_STUN'
      ) {
        f.state = f.isCrouching ? 'CROUCH' : 'IDLE';
      } else if (f.state === 'KNOCKDOWN') {
        f.state = 'GET_UP';
        f.stateFrame = 0;
        f.totalStateFrames = 22;
        f.invincibleFrames = 26; // Wake-up invincibility
      } else if (f.state === 'GET_UP') {
        f.state = 'IDLE';
      }
    }

    // Active Hitbox lifecycle (active on middle frames)
    if (f.activeHitbox) {
      const startup = Math.floor(f.totalStateFrames * 0.2);
      const activeEnd = Math.floor(f.totalStateFrames * 0.7);
      if (f.stateFrame < startup || f.stateFrame > activeEnd) {
        // Not in active window
      } else {
        // Update Hitbox X with current fighter position
        const reach = f.activeHitbox.width;
        f.activeHitbox.x = f.facing === 1 ? f.x + 20 : f.x - 20 - reach;
      }
    }
  }

  // ===================== COLLISION & DAMAGE RESOLUTION =====================

  private checkCollisions(attacker: FighterEntity, defender: FighterEntity) {
    if (!attacker.activeHitbox || attacker.hasHitInState) return;
    if (defender.invincibleFrames > 0 || defender.health <= 0) return;

    const hb = attacker.activeHitbox;
    const hurt = defender.hurtbox;

    // Check AABB overlap between Hitbox and Defender Hurtbox
    const isIntersecting =
      hb.x < hurt.x + hurt.width &&
      hb.x + hb.width > hurt.x &&
      hb.y < hurt.y + hurt.height &&
      hb.y + hb.height > hurt.y;

    if (isIntersecting) {
      attacker.hasHitInState = true;

      // Check Guarding
      const isGuardingHigh = defender.state === 'BLOCK_HIGH';
      const isGuardingLow = defender.state === 'BLOCK_LOW';
      let isBlocked = false;

      if (hb.hitType === 'HIGH' && isGuardingHigh) isBlocked = true;
      if (hb.hitType === 'LOW' && isGuardingLow) isBlocked = true;
      if (hb.hitType === 'MID' && (isGuardingHigh || isGuardingLow)) isBlocked = true;

      const hitX = (hb.x + hurt.x + hurt.width / 2) / 2;
      const hitY = (hb.y + hurt.y + hurt.height / 2) / 2;

      // Counter Hit Detection: defender was in an attack's startup/active frames
      const isCounter =
        !isBlocked &&
        (defender.state.startsWith('LIGHT') ||
          defender.state.startsWith('HEAVY') ||
          defender.state.startsWith('SPECIAL') ||
          defender.state === 'ULTIMATE') &&
        !defender.hasHitInState;

      if (isBlocked) {
        // Blocked Hit
        sound.playBlock();
        const chipDamage = hb.canChip ? Math.max(1, Math.floor(hb.damage * 0.2)) : 0;
        defender.health = Math.max(0, defender.health - chipDamage);
        defender.guardMeter = Math.max(0, defender.guardMeter - 12);
        defender.vx = attacker.facing * 4;
        this.addSparks(hitX, hitY, '#38bdf8', 6);
        this.state.hitStopTime = 4;
      } else {
        // Clean Hit or Counter Hit
        const counterBonus = isCounter ? 1.25 : 1.0;
        const damageDealt = Math.round(hb.damage * counterBonus);

        defender.health = Math.max(0, defender.health - damageDealt);
        defender.vx = hb.knockbackX;
        defender.vy = hb.knockbackY;

        // Meter build
        attacker.superMeter = Math.min(100, attacker.superMeter + (attacker.state === 'ULTIMATE' ? 0 : 15));
        defender.superMeter = Math.min(100, defender.superMeter + 8);

        // Combo Tracking
        attacker.comboHits++;
        attacker.comboDamage += damageDealt;

        // Hit stun / Knockdown
        if (hb.isKnockdown || !defender.isGrounded) {
          defender.state = 'KNOCKDOWN';
          defender.stateFrame = 0;
          defender.totalStateFrames = 40;
          defender.isGrounded = false;
        } else {
          defender.state = 'HIT_STUN';
          defender.stateFrame = 0;
          defender.totalStateFrames = hb.hitStun;
        }

        // SFX & Feedback
        if (attacker.state === 'ULTIMATE') {
          sound.playCriticalHit();
          this.state.shakeTime = 22;
          this.state.shakeIntensity = 14;
          this.state.hitStopTime = 10;
          this.addSparks(hitX, hitY, '#f59e0b', 35);
          this.addRing(hitX, hitY, '#ef4444');
        } else if (isCounter || hb.damage >= 15) {
          sound.playHeavyHit();
          this.state.shakeTime = 12;
          this.state.shakeIntensity = 7;
          this.state.hitStopTime = 6;
          this.addSparks(hitX, hitY, '#ef4444', 18);
          this.addRing(hitX, hitY, '#facc15');
        } else {
          sound.playLightHit();
          this.state.shakeTime = 5;
          this.state.shakeIntensity = 3;
          this.state.hitStopTime = 3;
          this.addSparks(hitX, hitY, '#facc15', 8);
        }

        if (isCounter) {
          this.state.isCounterHit = true;
          this.state.counterHitTextTime = 40;
          sound.announce('Counter Hit');
        }

        if (attacker.comboHits >= 3 && attacker.comboHits % 3 === 0) {
          sound.announce(`${attacker.comboHits} Hits`);
        }
      }
    }
  }

  // ===================== CPU AI BEHAVIOR =====================

  private updateAI() {
    this.aiStrategyTimer++;
    if (this.aiStrategyTimer % 18 !== 0) return;

    const cpu = this.p2;
    const opp = this.p1;
    const dist = Math.abs(cpu.x - opp.x);

    // Reset inputs
    this.p2Inputs.left = false;
    this.p2Inputs.right = false;
    this.p2Inputs.up = false;
    this.p2Inputs.down = false;
    this.p2Inputs.lightPunch = false;
    this.p2Inputs.heavyPunch = false;
    this.p2Inputs.lightKick = false;
    this.p2Inputs.heavyKick = false;
    this.p2Inputs.special1 = false;
    this.p2Inputs.special2 = false;
    this.p2Inputs.ultimate = false;
    this.p2Inputs.guard = false;

    // Difficulty probability modifiers
    const blockChance = this.difficulty === 'EASY' ? 0.35 : this.difficulty === 'MEDIUM' ? 0.65 : 0.88;
    const comboAggression = this.difficulty === 'EASY' ? 0.4 : this.difficulty === 'MEDIUM' ? 0.7 : 0.95;

    // 1. Reactive Guarding: If player is actively attacking and within reach
    if (opp.activeHitbox && dist < 150) {
      if (Math.random() < blockChance) {
        if (opp.activeHitbox.hitType === 'LOW') {
          this.p2Inputs.down = true;
          this.p2Inputs.guard = true;
        } else {
          this.p2Inputs.guard = true;
        }
        return;
      }
    }

    // 2. Ultimate when available
    if (cpu.superMeter >= 100 && dist < 170 && Math.random() < 0.6) {
      this.p2Inputs.ultimate = true;
      return;
    }

    // 3. Spacing / Movement
    const fwdKey = cpu.facing === 1 ? 'right' : 'left';
    const bwdKey = cpu.facing === 1 ? 'left' : 'right';

    if (dist > this.aiDesiredDistance + 30) {
      // Approach
      this.p2Inputs[fwdKey] = true;
      if (dist > 350 && Math.random() < 0.2) {
        this.p2Inputs.up = true; // jump in
      }
    } else if (dist < this.aiDesiredDistance - 40 && Math.random() < 0.3) {
      // Back step
      this.p2Inputs[bwdKey] = true;
    }

    // 4. Attack Selection when close
    if (dist <= 150 && Math.random() < comboAggression) {
      const roll = Math.random();
      if (roll < 0.25) {
        this.p2Inputs.special1 = true;
      } else if (roll < 0.45) {
        this.p2Inputs.special2 = true;
      } else if (roll < 0.65) {
        this.p2Inputs.heavyKick = true;
      } else if (roll < 0.82) {
        this.p2Inputs.heavyPunch = true;
      } else {
        this.p2Inputs.lightPunch = true;
      }
    }
  }

  // ===================== PARTICLE SYSTEM =====================

  private addSparks(x: number, y: number, color: string, count: number) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 3 + Math.random() * 9;
      this.state.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: 3 + Math.random() * 4,
        color,
        life: 0,
        maxLife: 14 + Math.random() * 10,
        type: 'spark',
      });
    }
  }

  private addRing(x: number, y: number, color: string) {
    this.state.particles.push({
      x,
      y,
      vx: 0,
      vy: 0,
      size: 15,
      color,
      life: 0,
      maxLife: 18,
      type: 'ring',
    });
  }

  private addDustPuff(x: number, y: number) {
    for (let i = 0; i < 6; i++) {
      this.state.particles.push({
        x: x + (Math.random() - 0.5) * 30,
        y: y - 5,
        vx: (Math.random() - 0.5) * 3,
        vy: -Math.random() * 2,
        size: 8 + Math.random() * 8,
        color: '#e2e8f0',
        life: 0,
        maxLife: 20,
        type: 'smoke',
      });
    }
  }

  private updateParticles() {
    for (let i = this.state.particles.length - 1; i >= 0; i--) {
      const p = this.state.particles[i];
      p.life++;
      p.x += p.vx;
      p.y += p.vy;

      if (p.type === 'spark') {
        p.vx *= 0.92;
        p.vy *= 0.92;
      } else if (p.type === 'ring') {
        p.size += 5;
      } else if (p.type === 'smoke') {
        p.size *= 1.04;
        p.vy -= 0.1;
      }

      if (p.life >= p.maxLife) {
        this.state.particles.splice(i, 1);
      }
    }
  }
}
