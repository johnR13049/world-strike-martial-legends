/**
 * World Strike: Martial Legends - Fighter & Combat Types
 */

export type MartialArtDiscipline = 
  | 'KYOKUSHIN'
  | 'MUAY_THAI'
  | 'LETHWEI'
  | 'WUSHU_SANDA'
  | 'YAW_YAN';

export type FighterArchetype = 
  | 'Pressure Fighter'
  | 'Counter Fighter'
  | 'Low-Kick Specialist'
  | 'High-Kick Specialist'
  | 'Heavy KO Brawler'
  | 'Technical Fighter'
  | 'Knee Specialist'
  | 'Powerful Puncher'
  | 'Kick Specialist'
  | 'Aggressive Close-Range'
  | 'Aggressive Pressure Fighter'
  | 'Counter Striker'
  | 'Heavy Puncher'
  | 'Close-Range Fighter'
  | 'Extremely Durable Brawler'
  | 'Fast Striker'
  | 'Side-Kick Specialist'
  | 'Aggressive Combination Fighter'
  | 'Explosive Fighter'
  | 'Fast Kicker'
  | 'Spinning-Kick Specialist'
  | 'Powerful All-Rounder';

export interface MoveData {
  name: string;
  command: string; // e.g. "↓ ↘ → + Punch"
  description: string;
  damage: number;
  meterCost: number; // 0 for normals/specials, 100 for ultimate
  hitType: 'HIGH' | 'MID' | 'LOW' | 'THROW';
  isKnockdown?: boolean;
}

export interface FighterAttributes {
  power: number;      // 1-10
  speed: number;      // 1-10
  defense: number;    // 1-10
  range: number;      // 1-10
  technique: number;  // 1-10
}

export interface FighterVisuals {
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  skinTone: string;
  hairColor: string;
  hairStyle: 'bald' | 'short' | 'topknot' | 'spiky' | 'headband' | 'dreads' | 'slick';
  build: 'heavy' | 'muscular' | 'lean' | 'tall';
  attire: 'karate_gi' | 'muay_thai' | 'lethwei_wraps' | 'sanda_rashguard' | 'yaw_yan_trunks';
  trailColor: string;
  stanceStyle: 'kyokushin' | 'muay_thai' | 'lethwei' | 'sanda' | 'yaw_yan';
}

export interface FighterData {
  id: string;
  name: string;
  epithet: string;
  discipline: MartialArtDiscipline;
  archetype: FighterArchetype;
  country: string;
  flag: string;
  bio: string;
  quote: string;
  winQuote: string;
  attributes: FighterAttributes;
  visuals: FighterVisuals;
  moves: {
    special1: MoveData;
    special2: MoveData;
    ultimate: MoveData;
  };
}

export type FighterActionState =
  | 'IDLE'
  | 'WALK_FORWARD'
  | 'WALK_BACKWARD'
  | 'CROUCH'
  | 'JUMP_START'
  | 'JUMPING'
  | 'DASH_FORWARD'
  | 'DASH_BACKWARD'
  | 'LIGHT_PUNCH'
  | 'HEAVY_PUNCH'
  | 'LIGHT_KICK'
  | 'HEAVY_KICK'
  | 'SPECIAL_1'
  | 'SPECIAL_2'
  | 'ULTIMATE'
  | 'BLOCK_HIGH'
  | 'BLOCK_LOW'
  | 'HIT_STUN'
  | 'KNOCKDOWN'
  | 'GET_UP'
  | 'VICTORY'
  | 'DEFEAT';

export interface Hitbox {
  x: number;
  y: number;
  width: number;
  height: number;
  damage: number;
  hitType: 'HIGH' | 'MID' | 'LOW' | 'THROW';
  hitStun: number;
  blockStun: number;
  knockbackX: number;
  knockbackY: number;
  isKnockdown: boolean;
  canChip: boolean;
}

export interface Hurtbox {
  x: number;
  y: number;
  width: number;
  height: number;
  isCrouching?: boolean;
}

export interface ParticleEffect {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  life: number;
  maxLife: number;
  type: 'spark' | 'smoke' | 'blood' | 'ring' | 'trail' | 'speedline';
}

export interface StageData {
  id: string;
  name: string;
  location: string;
  country: string;
  bgSkyGradient: [string, string];
  bgArchitectureType: 'japan_dojo' | 'thai_stadium' | 'yangon_pit' | 'china_mountain' | 'philippines_gym' | 'underground_cage' | 'grand_arena';
  floorColor: string;
  lineColor: string;
  atmosphereParticles: 'leaves' | 'sweat_dust' | 'sand_embers' | 'mountain_mist' | 'gym_dust' | 'neon_sparks' | 'confetti';
}
